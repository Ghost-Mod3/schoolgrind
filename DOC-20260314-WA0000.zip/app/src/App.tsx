import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { ThemeProvider } from './contexts/ThemeContext';
import { AuthProvider } from './contexts/AuthContext';
import LandingPage from './pages/LandingPage';
import Login from './pages/Login';
import Signup from './pages/Signup';
import Dashboard from './pages/Dashboard';
import AiTutor from './pages/AiTutor';
import NotesGenerator from './pages/NotesGenerator';
import QuizGenerator from './pages/QuizGenerator';
import HomeworkScanner from './pages/HomeworkScanner';
import ProgressTracking from './pages/ProgressTracking';
import StudyLibrary from './pages/StudyLibrary';
import AdminDashboard from './pages/AdminDashboard';
import ProtectedRoute from './components/ProtectedRoute';

function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <Router>
          <Routes>
            {/* Public Routes */}
            <Route path="/" element={<LandingPage />} />
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<Signup />} />
            
            {/* Protected Routes */}
            <Route element={<ProtectedRoute />}>
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/ai-tutor" element={<AiTutor />} />
              <Route path="/notes" element={<NotesGenerator />} />
              <Route path="/quiz" element={<QuizGenerator />} />
              <Route path="/scanner" element={<HomeworkScanner />} />
              <Route path="/progress" element={<ProgressTracking />} />
              <Route path="/library" element={<StudyLibrary />} />
            </Route>
            
            {/* Admin Route */}
            <Route element={<ProtectedRoute requireAdmin={true} />}>
              <Route path="/admin" element={<AdminDashboard />} />
            </Route>
          </Routes>
        </Router>
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;
