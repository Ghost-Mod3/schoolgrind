import { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  ArrowLeft, Search, BookOpen, FileText, HelpCircle, 
  Camera, Trash2, Download, Folder,
  Grid3X3, List, Filter
} from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';

interface LibraryItem {
  id: string;
  title: string;
  type: 'notes' | 'quiz' | 'scan' | 'document';
  subject: string;
  createdAt: Date;
  size?: string;
}

const mockLibraryItems: LibraryItem[] = [
  { id: '1', title: 'Calculus Derivatives Notes', type: 'notes', subject: 'Mathematics', createdAt: new Date('2026-03-10'), size: '12 KB' },
  { id: '2', title: 'Biology Quiz - Cell Structure', type: 'quiz', subject: 'Science', createdAt: new Date('2026-03-09') },
  { id: '3', title: 'Homework Scan - Algebra', type: 'scan', subject: 'Mathematics', createdAt: new Date('2026-03-08'), size: '2.4 MB' },
  { id: '4', title: 'World War II Summary', type: 'notes', subject: 'History', createdAt: new Date('2026-03-07'), size: '8 KB' },
  { id: '5', title: 'Physics Formulas', type: 'notes', subject: 'Science', createdAt: new Date('2026-03-06'), size: '15 KB' },
  { id: '6', title: 'Chemistry Quiz - Periodic Table', type: 'quiz', subject: 'Science', createdAt: new Date('2026-03-05') },
  { id: '7', title: 'Essay Draft - Shakespeare', type: 'document', subject: 'Literature', createdAt: new Date('2026-03-04'), size: '45 KB' },
  { id: '8', title: 'Geometry Problem Set', type: 'scan', subject: 'Mathematics', createdAt: new Date('2026-03-03'), size: '1.8 MB' },
];

const subjects = ['All', 'Mathematics', 'Science', 'History', 'Literature', 'Languages'];

export default function StudyLibrary() {
  const { theme } = useTheme();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSubject, setSelectedSubject] = useState('All');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [items, setItems] = useState(mockLibraryItems);

  const filteredItems = items.filter(item => {
    const matchesSearch = item.title.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesSubject = selectedSubject === 'All' || item.subject === selectedSubject;
    return matchesSearch && matchesSubject;
  });

  const getItemIcon = (type: string) => {
    switch (type) {
      case 'notes': return FileText;
      case 'quiz': return HelpCircle;
      case 'scan': return Camera;
      case 'document': return BookOpen;
      default: return FileText;
    }
  };

  const getItemColor = (type: string) => {
    switch (type) {
      case 'notes': return 'bg-violet/20 text-violet';
      case 'quiz': return 'bg-lime/20 text-lime';
      case 'scan': return 'bg-orange-500/20 text-orange-400';
      case 'document': return 'bg-blue-500/20 text-blue-400';
      default: return 'bg-white/10 text-white';
    }
  };

  const handleDelete = (id: string) => {
    setItems(items.filter(item => item.id !== id));
  };

  return (
    <div className={`min-h-screen ${theme === 'dark' ? 'bg-[#0B0B0D]' : 'bg-gray-50'} transition-colors`}>
      {/* Header */}
      <header className={`${theme === 'dark' ? 'bg-[#0B0B0D]/90' : 'bg-white/90'} backdrop-blur-md border-b ${theme === 'dark' ? 'border-white/10' : 'border-gray-200'} sticky top-0 z-40`}>
        <div className="px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center gap-4">
            <Link 
              to="/dashboard" 
              className={`p-2 rounded-xl ${theme === 'dark' ? 'bg-white/10 text-white' : 'bg-gray-100 text-gray-700'} hover:bg-lime hover:text-[#0B0B0D] transition-colors`}
            >
              <ArrowLeft className="w-5 h-5" />
            </Link>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-violet/20 flex items-center justify-center">
                <BookOpen className="w-6 h-6 text-violet" />
              </div>
              <div>
                <h1 className={`font-display font-bold text-xl ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                  Study Library
                </h1>
                <p className={`text-sm ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-500'}`}>
                  {items.length} saved items
                </p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="px-4 sm:px-6 lg:px-8 py-8">
        <div className="max-w-6xl mx-auto">
          {/* Search & Filters */}
          <div className={`neon-card p-4 mb-6 ${theme === 'light' ? 'bg-white' : ''}`}>
            <div className="flex flex-col lg:flex-row gap-4">
              {/* Search */}
              <div className="flex-1 relative">
                <Search className={`absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-400'}`} />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search your study materials..."
                  className={`w-full pl-12 pr-4 py-3 rounded-xl border-2 transition-colors ${
                    theme === 'dark'
                      ? 'bg-white/[0.06] border-white/[0.2] text-white placeholder:text-[#A7A7AD] focus:border-lime'
                      : 'bg-gray-50 border-gray-200 text-gray-900 placeholder:text-gray-400 focus:border-lime'
                  }`}
                />
              </div>

              {/* Subject Filter */}
              <div className="flex items-center gap-2 overflow-x-auto pb-2 lg:pb-0">
                <Filter className={`w-5 h-5 flex-shrink-0 ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-400'}`} />
                {subjects.map((subject) => (
                  <button
                    key={subject}
                    onClick={() => setSelectedSubject(subject)}
                    className={`px-4 py-2 rounded-xl whitespace-nowrap transition-colors ${
                      selectedSubject === subject
                        ? 'bg-lime text-[#0B0B0D]'
                        : theme === 'dark'
                          ? 'bg-white/10 text-white hover:bg-white/20'
                          : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    {subject}
                  </button>
                ))}
              </div>

              {/* View Toggle */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setViewMode('grid')}
                  className={`p-3 rounded-xl transition-colors ${
                    viewMode === 'grid'
                      ? 'bg-lime text-[#0B0B0D]'
                      : theme === 'dark'
                        ? 'bg-white/10 text-white'
                        : 'bg-gray-100 text-gray-700'
                  }`}
                >
                  <Grid3X3 className="w-5 h-5" />
                </button>
                <button
                  onClick={() => setViewMode('list')}
                  className={`p-3 rounded-xl transition-colors ${
                    viewMode === 'list'
                      ? 'bg-lime text-[#0B0B0D]'
                      : theme === 'dark'
                        ? 'bg-white/10 text-white'
                        : 'bg-gray-100 text-gray-700'
                  }`}
                >
                  <List className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>

          {/* Items Grid/List */}
          {filteredItems.length > 0 ? (
            <div className={viewMode === 'grid' ? 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4' : 'space-y-3'}>
              {filteredItems.map((item) => {
                const Icon = getItemIcon(item.type);
                return (
                  <div
                    key={item.id}
                    className={`neon-card p-5 group hover:scale-[1.02] transition-transform ${
                      theme === 'light' ? 'bg-white' : ''
                    } ${viewMode === 'list' ? 'flex items-center gap-4' : ''}`}
                  >
                    {/* Icon */}
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 ${getItemColor(item.type)}`}>
                      <Icon className="w-6 h-6" />
                    </div>

                    {/* Content */}
                    <div className={`flex-1 min-w-0 ${viewMode === 'grid' ? 'mt-4' : ''}`}>
                      <h3 className={`font-semibold truncate ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                        {item.title}
                      </h3>
                      <div className={`flex items-center gap-3 mt-1 text-sm ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-500'}`}>
                        <span className="flex items-center gap-1">
                          <Folder className="w-3 h-3" />
                          {item.subject}
                        </span>
                        <span>•</span>
                        <span>{item.createdAt.toLocaleDateString()}</span>
                        {item.size && (
                          <>
                            <span>•</span>
                            <span>{item.size}</span>
                          </>
                        )}
                      </div>
                    </div>

                    {/* Actions */}
                    <div className={`flex items-center gap-2 ${viewMode === 'grid' ? 'mt-4 pt-4 border-t border-white/10' : ''}`}>
                      <button
                        className={`p-2 rounded-lg ${theme === 'dark' ? 'bg-white/10 text-white' : 'bg-gray-100 text-gray-700'} hover:bg-lime hover:text-[#0B0B0D] transition-colors`}
                        title="Download"
                      >
                        <Download className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDelete(item.id)}
                        className={`p-2 rounded-lg ${theme === 'dark' ? 'bg-white/10 text-white' : 'bg-gray-100 text-gray-700'} hover:bg-red-500 hover:text-white transition-colors`}
                        title="Delete"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            /* Empty State */
            <div className={`text-center py-16 ${theme === 'light' ? 'bg-white' : ''} neon-card`}>
              <BookOpen className={`w-16 h-16 mx-auto mb-4 ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-400'}`} />
              <h3 className={`font-semibold text-xl mb-2 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                No items found
              </h3>
              <p className={theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-600'}>
                {searchQuery ? 'Try a different search term' : 'Your study library is empty'}
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
