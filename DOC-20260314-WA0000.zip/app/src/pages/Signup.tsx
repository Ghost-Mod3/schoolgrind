import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Eye, EyeOff, Mail, Lock, User, ArrowRight, CheckCircle } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';

export default function Signup() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [agreeTerms, setAgreeTerms] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  
  const { signup } = useAuth();
  const { theme } = useTheme();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (password !== confirmPassword) {
      setError('Passwords do not match');
      return;
    }
    
    if (password.length < 8) {
      setError('Password must be at least 8 characters');
      return;
    }
    
    if (!agreeTerms) {
      setError('Please agree to the terms and conditions');
      return;
    }
    
    setIsLoading(true);
    
    try {
      const success = await signup(name, email, password);
      if (success) {
        navigate('/dashboard');
      }
    } catch {
      setError('Something went wrong. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const passwordStrength = () => {
    let strength = 0;
    if (password.length >= 8) strength++;
    if (/[A-Z]/.test(password)) strength++;
    if (/[0-9]/.test(password)) strength++;
    if (/[^A-Za-z0-9]/.test(password)) strength++;
    return strength;
  };

  return (
    <div className={`min-h-screen flex ${theme === 'dark' ? 'bg-[#0B0B0D]' : 'bg-gray-50'} transition-colors`}>
      {/* Left Side - Image */}
      <div className="hidden lg:flex lg:w-1/2 relative">
        <img
          src="/images/focus_student_laptop.jpg"
          alt="Student studying"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0B0B0D]/80 to-transparent" />
        <div className="absolute bottom-12 left-12 right-12">
          <h2 className="text-white font-display font-bold text-4xl mb-4">
            Start Your Journey
          </h2>
          <p className="text-white/80 text-lg">
            Join thousands of students studying smarter with SchoolGrind.
          </p>
        </div>
      </div>

      {/* Right Side - Form */}
      <div className={`w-full lg:w-1/2 flex items-center justify-center p-8 ${theme === 'dark' ? 'bg-[#0B0B0D]' : 'bg-white'}`}>
        <div className="w-full max-w-md">
          {/* Logo */}
          <Link to="/" className="inline-block mb-8">
            <span className="text-lime font-display font-bold text-2xl">SchoolGrind</span>
          </Link>

          <h1 className={`font-display font-bold text-3xl mb-2 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
            Create Account
          </h1>
          <p className={`mb-8 ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-600'}`}>
            Sign up to start studying smarter
          </p>

          {error && (
            <div className="mb-6 p-4 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 text-sm">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Full Name */}
            <div>
              <label className={`block text-sm font-medium mb-2 ${theme === 'dark' ? 'text-white' : 'text-gray-700'}`}>
                Full Name
              </label>
              <div className="relative">
                <User className={`absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-400'}`} />
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="John Doe"
                  className={`w-full pl-12 pr-4 py-3 rounded-xl border-2 transition-colors ${
                    theme === 'dark'
                      ? 'bg-white/[0.06] border-white/[0.2] text-white placeholder:text-[#A7A7AD] focus:border-lime'
                      : 'bg-gray-50 border-gray-200 text-gray-900 placeholder:text-gray-400 focus:border-lime'
                  }`}
                  required
                />
              </div>
            </div>

            {/* Email */}
            <div>
              <label className={`block text-sm font-medium mb-2 ${theme === 'dark' ? 'text-white' : 'text-gray-700'}`}>
                Email
              </label>
              <div className="relative">
                <Mail className={`absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-400'}`} />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@school.edu"
                  className={`w-full pl-12 pr-4 py-3 rounded-xl border-2 transition-colors ${
                    theme === 'dark'
                      ? 'bg-white/[0.06] border-white/[0.2] text-white placeholder:text-[#A7A7AD] focus:border-lime'
                      : 'bg-gray-50 border-gray-200 text-gray-900 placeholder:text-gray-400 focus:border-lime'
                  }`}
                  required
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <label className={`block text-sm font-medium mb-2 ${theme === 'dark' ? 'text-white' : 'text-gray-700'}`}>
                Password
              </label>
              <div className="relative">
                <Lock className={`absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-400'}`} />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className={`w-full pl-12 pr-12 py-3 rounded-xl border-2 transition-colors ${
                    theme === 'dark'
                      ? 'bg-white/[0.06] border-white/[0.2] text-white placeholder:text-[#A7A7AD] focus:border-lime'
                      : 'bg-gray-50 border-gray-200 text-gray-900 placeholder:text-gray-400 focus:border-lime'
                  }`}
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className={`absolute right-4 top-1/2 -translate-y-1/2 ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-400'}`}
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
              
              {/* Password Strength */}
              {password && (
                <div className="mt-2 flex items-center gap-2">
                  <div className="flex-1 h-1 bg-white/10 rounded-full overflow-hidden">
                    <div
                      className={`h-full transition-all ${
                        passwordStrength() === 1 ? 'w-1/4 bg-red-500' :
                        passwordStrength() === 2 ? 'w-2/4 bg-yellow-500' :
                        passwordStrength() === 3 ? 'w-3/4 bg-lime' :
                        'w-full bg-lime'
                      }`}
                    />
                  </div>
                  <span className={`text-xs ${
                    passwordStrength() < 2 ? 'text-red-400' :
                    passwordStrength() < 3 ? 'text-yellow-400' :
                    'text-lime'
                  }`}>
                    {passwordStrength() < 2 ? 'Weak' :
                     passwordStrength() < 3 ? 'Fair' :
                     passwordStrength() < 4 ? 'Good' : 'Strong'}
                  </span>
                </div>
              )}
            </div>

            {/* Confirm Password */}
            <div>
              <label className={`block text-sm font-medium mb-2 ${theme === 'dark' ? 'text-white' : 'text-gray-700'}`}>
                Confirm Password
              </label>
              <div className="relative">
                <Lock className={`absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-400'}`} />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="••••••••"
                  className={`w-full pl-12 pr-4 py-3 rounded-xl border-2 transition-colors ${
                    theme === 'dark'
                      ? 'bg-white/[0.06] border-white/[0.2] text-white placeholder:text-[#A7A7AD] focus:border-lime'
                      : 'bg-gray-50 border-gray-200 text-gray-900 placeholder:text-gray-400 focus:border-lime'
                  }`}
                  required
                />
                {confirmPassword && password === confirmPassword && (
                  <CheckCircle className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-lime" />
                )}
              </div>
            </div>

            {/* Terms */}
            <label className="flex items-start gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={agreeTerms}
                onChange={(e) => setAgreeTerms(e.target.checked)}
                className="mt-1 w-4 h-4 rounded border-2 border-lime bg-transparent text-lime focus:ring-lime"
              />
              <span className={`text-sm ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-600'}`}>
                I agree to the{' '}
                <Link to="/terms" className="text-lime hover:underline">Terms of Service</Link>
                {' '}and{' '}
                <Link to="/privacy" className="text-lime hover:underline">Privacy Policy</Link>
              </span>
            </label>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full btn-lime flex items-center justify-center gap-2 py-4 disabled:opacity-50"
            >
              {isLoading ? (
                <div className="animate-spin rounded-full h-5 w-5 border-t-2 border-b-2 border-[#0B0B0D]" />
              ) : (
                <>
                  Create Account
                  <ArrowRight className="w-5 h-5" />
                </>
              )}
            </button>
          </form>

          {/* Sign In Link */}
          <p className={`mt-8 text-center ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-600'}`}>
            Already have an account?{' '}
            <Link to="/login" className="text-lime font-semibold hover:underline">
              Sign in
            </Link>
          </p>

          {/* Back to Home */}
          <Link
            to="/"
            className={`mt-6 inline-flex items-center gap-2 text-sm ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-500'} hover:text-lime transition-colors`}
          >
            <ArrowRight className="w-4 h-4 rotate-180" />
            Back to home
          </Link>
        </div>
      </div>
    </div>
  );
}
