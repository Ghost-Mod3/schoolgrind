import { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  ArrowLeft, FileText, Sparkles, Download, Save, 
  Copy, Check, Upload, Type, BookOpen, Loader2
} from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';

interface GeneratedNote {
  id: string;
  title: string;
  content: string;
  type: 'summary' | 'bullet' | 'key-concepts' | 'revision';
  createdAt: Date;
}

const noteTypes = [
  { id: 'summary', label: 'Summary', description: 'Concise overview of main points' },
  { id: 'bullet', label: 'Bullet Points', description: 'Key points in list format' },
  { id: 'key-concepts', label: 'Key Concepts', description: 'Important terms and definitions' },
  { id: 'revision', label: 'Revision Notes', description: 'Study-friendly condensed notes' },
];

export default function NotesGenerator() {
  const { theme } = useTheme();
  const [input, setInput] = useState('');
  const [selectedType, setSelectedType] = useState('summary');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedNote, setGeneratedNote] = useState<GeneratedNote | null>(null);
  const [savedNotes, setSavedNotes] = useState<GeneratedNote[]>([]);
  const [copied, setCopied] = useState(false);

  const handleGenerate = async () => {
    if (!input.trim()) return;

    setIsGenerating(true);

    // Simulate AI generation
    setTimeout(() => {
      const note: GeneratedNote = {
        id: Date.now().toString(),
        title: `Notes on "${input.slice(0, 50)}..."`,
        content: generateMockContent(input, selectedType),
        type: selectedType as any,
        createdAt: new Date(),
      };
      setGeneratedNote(note);
      setIsGenerating(false);
    }, 2000);
  };

  const generateMockContent = (topic: string, type: string): string => {
    const contents: Record<string, string> = {
      summary: `# Summary: ${topic}\n\n## Overview\nThis topic covers the fundamental principles and key concepts that are essential for understanding the subject matter.\n\n## Main Points\n1. First important concept related to ${topic}\n2. Second key principle that builds upon the first\n3. Practical applications and real-world examples\n4. Common misconceptions to avoid\n\n## Conclusion\nUnderstanding these concepts will provide a solid foundation for further study.`,
      
      bullet: `# Key Points: ${topic}\n\n• Core concept #1: Definition and explanation\n• Core concept #2: How it relates to the bigger picture\n• Important formula/term: Remember this for exams\n• Common mistake students make\n• Pro tip for memorization\n• Real-world application example\n• Related topics to explore next`,
      
      'key-concepts': `# Key Concepts: ${topic}\n\n## Term 1: [Important Term]\n**Definition:** Clear explanation of what this means\n**Example:** Concrete example to illustrate\n**Why it matters:** How this connects to the broader topic\n\n## Term 2: [Another Key Term]\n**Definition:** Clear explanation\n**Formula/Equation:** If applicable\n**Application:** When and how to use this`,
      
      revision: `# Revision Notes: ${topic}\n\n## Quick Facts\n✓ Must know #1\n✓ Must know #2\n✓ Must know #3\n\n## Formulas to Remember\n• Formula 1: [equation]\n• Formula 2: [equation]\n\n## Common Exam Questions\n1. Typical question format...\n2. Another common question...\n\n## 5-Minute Review\nRead through these points before your exam!`,
    };
    return contents[type] || contents.summary;
  };

  const handleSave = () => {
    if (generatedNote) {
      setSavedNotes((prev) => [generatedNote, ...prev]);
    }
  };

  const handleCopy = () => {
    if (generatedNote) {
      navigator.clipboard.writeText(generatedNote.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleDownload = () => {
    if (generatedNote) {
      const blob = new Blob([generatedNote.content], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${generatedNote.title.replace(/[^a-z0-9]/gi, '_').toLowerCase()}.txt`;
      a.click();
      URL.revokeObjectURL(url);
    }
  };

  return (
    <div className={`min-h-screen ${theme === 'dark' ? 'bg-[#0B0B0D]' : 'bg-gray-50'} transition-colors`}>
      {/* Header */}
      <header className={`${theme === 'dark' ? 'bg-[#0B0B0D]/90' : 'bg-white/90'} backdrop-blur-md border-b ${theme === 'dark' ? 'border-white/10' : 'border-gray-200'} sticky top-0 z-40`}>
        <div className="px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center gap-4">
            <Link 
              to="/dashboard" 
              className={`p-2 rounded-xl ${theme === 'dark' ? 'bg-white/10 text-white' : 'bg-gray-100 text-gray-700'} hover:bg-lime hover:text-[#0B0B0D] transition-colors`}
            >
              <ArrowLeft className="w-5 h-5" />
            </Link>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-violet/20 flex items-center justify-center">
                <FileText className="w-6 h-6 text-violet" />
              </div>
              <div>
                <h1 className={`font-display font-bold text-xl ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                  AI Notes Generator
                </h1>
                <p className={`text-sm ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-500'}`}>
                  Transform content into study notes
                </p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="px-4 sm:px-6 lg:px-8 py-8">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Input Section */}
            <div>
              {/* Note Type Selector */}
              <div className="mb-6">
                <label className={`block text-sm font-medium mb-3 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                  Choose Note Type
                </label>
                <div className="grid grid-cols-2 gap-3">
                  {noteTypes.map((type) => (
                    <button
                      key={type.id}
                      onClick={() => setSelectedType(type.id)}
                      className={`p-4 rounded-xl border-2 text-left transition-colors ${
                        selectedType === type.id
                          ? 'border-lime bg-lime/10'
                          : theme === 'dark'
                            ? 'border-white/10 hover:border-white/30'
                            : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <p className={`font-semibold ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                        {type.label}
                      </p>
                      <p className={`text-xs mt-1 ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-500'}`}>
                        {type.description}
                      </p>
                    </button>
                  ))}
                </div>
              </div>

              {/* Input Methods */}
              <div className={`neon-card p-6 ${theme === 'light' ? 'bg-white' : ''}`}>
                <div className="flex items-center gap-2 mb-4">
                  <Type className="w-5 h-5 text-lime" />
                  <span className={`font-semibold ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                    Enter Topic or Content
                  </span>
                </div>
                
                <textarea
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Enter a topic (e.g., 'Photosynthesis') or paste your class notes here..."
                  className={`w-full h-48 p-4 rounded-xl border-2 resize-none transition-colors ${
                    theme === 'dark'
                      ? 'bg-white/[0.06] border-white/[0.2] text-white placeholder:text-[#A7A7AD] focus:border-lime'
                      : 'bg-gray-50 border-gray-200 text-gray-900 placeholder:text-gray-400 focus:border-lime'
                  }`}
                />

                <div className="flex items-center gap-3 mt-4">
                  <button
                    onClick={handleGenerate}
                    disabled={!input.trim() || isGenerating}
                    className="flex-1 btn-lime flex items-center justify-center gap-2 py-3 disabled:opacity-50"
                  >
                    {isGenerating ? (
                      <>
                        <Loader2 className="w-5 h-5 animate-spin" />
                        Generating...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-5 h-5" />
                        Generate Notes
                      </>
                    )}
                  </button>
                  
                  <button
                    className={`p-3 rounded-xl border-2 ${theme === 'dark' ? 'border-white/20 text-white' : 'border-gray-200 text-gray-700'} hover:border-lime hover:text-lime transition-colors`}
                  >
                    <Upload className="w-5 h-5" />
                  </button>
                </div>
              </div>

              {/* Saved Notes */}
              {savedNotes.length > 0 && (
                <div className={`mt-6 neon-card p-6 ${theme === 'light' ? 'bg-white' : ''}`}>
                  <h3 className={`font-semibold mb-4 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                    Saved Notes ({savedNotes.length})
                  </h3>
                  <div className="space-y-3">
                    {savedNotes.slice(0, 5).map((note) => (
                      <div
                        key={note.id}
                        className={`flex items-center gap-3 p-3 rounded-xl ${theme === 'dark' ? 'bg-white/[0.04]' : 'bg-gray-50'}`}
                      >
                        <BookOpen className="w-5 h-5 text-lime" />
                        <div className="flex-1 min-w-0">
                          <p className={`text-sm truncate ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                            {note.title}
                          </p>
                          <p className={`text-xs ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-500'}`}>
                            {note.createdAt.toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Output Section */}
            <div>
              <div className={`neon-card p-6 min-h-[500px] ${theme === 'light' ? 'bg-white' : ''}`}>
                <div className="flex items-center justify-between mb-4">
                  <h3 className={`font-semibold ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                    Generated Notes
                  </h3>
                  {generatedNote && (
                    <div className="flex items-center gap-2">
                      <button
                        onClick={handleCopy}
                        className={`p-2 rounded-lg ${theme === 'dark' ? 'bg-white/10' : 'bg-gray-100'} hover:bg-lime hover:text-[#0B0B0D] transition-colors`}
                        title="Copy"
                      >
                        {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                      </button>
                      <button
                        onClick={handleSave}
                        className={`p-2 rounded-lg ${theme === 'dark' ? 'bg-white/10' : 'bg-gray-100'} hover:bg-lime hover:text-[#0B0B0D] transition-colors`}
                        title="Save"
                      >
                        <Save className="w-4 h-4" />
                      </button>
                      <button
                        onClick={handleDownload}
                        className={`p-2 rounded-lg ${theme === 'dark' ? 'bg-white/10' : 'bg-gray-100'} hover:bg-lime hover:text-[#0B0B0D] transition-colors`}
                        title="Download"
                      >
                        <Download className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                </div>

                {generatedNote ? (
                  <div className={`${theme === 'dark' ? 'text-white' : 'text-gray-900'} whitespace-pre-line font-mono text-sm leading-relaxed`}>
                    {generatedNote.content}
                  </div>
                ) : (
                  <div className={`h-full flex flex-col items-center justify-center text-center ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-500'}`}>
                    <Sparkles className="w-16 h-16 mb-4 opacity-30" />
                    <p>Your generated notes will appear here</p>
                    <p className="text-sm mt-2">Enter a topic and click Generate</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
