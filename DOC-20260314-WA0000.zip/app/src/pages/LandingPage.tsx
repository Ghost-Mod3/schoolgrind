import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import Navigation from '../components/Navigation';
import HeroSection from '../sections/HeroSection';
import StatementSection from '../sections/StatementSection';
import FeaturePlan from '../sections/FeaturePlan';
import FeatureFocus from '../sections/FeatureFocus';
import FeatureCollaborate from '../sections/FeatureCollaborate';
import FeatureTasks from '../sections/FeatureTasks';
import FeatureHabits from '../sections/FeatureHabits';
import SocialProof from '../sections/SocialProof';
import FinalCTA from '../sections/FinalCTA';
import DashboardSchedule from '../sections/DashboardSchedule';
import DashboardFocus from '../sections/DashboardFocus';
import DashboardTasks from '../sections/DashboardTasks';
import Footer from '../sections/Footer';

gsap.registerPlugin(ScrollTrigger);

export default function LandingPage() {
  const mainRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const timer = setTimeout(() => {
      const pinned = ScrollTrigger.getAll()
        .filter(st => st.vars.pin)
        .sort((a, b) => a.start - b.start);
      
      const maxScroll = ScrollTrigger.maxScroll(window);
      
      if (!maxScroll || pinned.length === 0) return;

      const pinnedRanges = pinned.map(st => ({
        start: st.start / maxScroll,
        end: (st.end ?? st.start) / maxScroll,
        center: (st.start + ((st.end ?? st.start) - st.start) * 0.5) / maxScroll,
      }));

      ScrollTrigger.create({
        snap: {
          snapTo: (value: number) => {
            const inPinned = pinnedRanges.some(r => value >= r.start - 0.02 && value <= r.end + 0.02);
            if (!inPinned) return value;

            const target = pinnedRanges.reduce((closest, r) =>
              Math.abs(r.center - value) < Math.abs(closest - value) ? r.center : closest,
              pinnedRanges[0]?.center ?? 0
            );
            return target;
          },
          duration: { min: 0.15, max: 0.35 },
          delay: 0,
          ease: "power2.out"
        }
      });
    }, 500);

    return () => {
      clearTimeout(timer);
      ScrollTrigger.getAll().forEach(st => st.kill());
    };
  }, []);

  return (
    <div ref={mainRef} className="relative bg-[#0B0B0D] min-h-screen">
      <div className="noise-overlay" />
      <Navigation />
      <main className="relative">
        <HeroSection />
        <StatementSection />
        <FeaturePlan />
        <FeatureFocus />
        <FeatureCollaborate />
        <FeatureTasks />
        <FeatureHabits />
        <SocialProof />
        <FinalCTA />
        <DashboardSchedule />
        <DashboardFocus />
        <DashboardTasks />
        <Footer />
      </main>
    </div>
  );
}
