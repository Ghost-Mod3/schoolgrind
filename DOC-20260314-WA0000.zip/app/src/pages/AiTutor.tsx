import { useState, useRef, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  Send, Bot, User, ArrowLeft, Sparkles, 
  BookOpen, Calculator, FlaskConical, Globe, 
  History, Languages, Briefcase, TrendingUp
} from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

const subjects = [
  { icon: Calculator, name: 'Mathematics', color: 'bg-blue-500/20 text-blue-400' },
  { icon: FlaskConical, name: 'Science', color: 'bg-green-500/20 text-green-400' },
  { icon: Globe, name: 'Geography', color: 'bg-orange-500/20 text-orange-400' },
  { icon: History, name: 'History', color: 'bg-purple-500/20 text-purple-400' },
  { icon: Languages, name: 'Languages', color: 'bg-pink-500/20 text-pink-400' },
  { icon: Briefcase, name: 'Business', color: 'bg-yellow-500/20 text-yellow-400' },
  { icon: TrendingUp, name: 'Economics', color: 'bg-cyan-500/20 text-cyan-400' },
  { icon: BookOpen, name: 'Other', color: 'bg-lime/20 text-lime' },
];

const sampleResponses: Record<string, string> = {
  'math': "I'd be happy to help with math! What topic are you working on? Algebra, calculus, geometry, or something else?",
  'science': "Science is fascinating! Are you studying physics, chemistry, biology, or another branch?",
  'history': "History helps us understand the present! What time period or event are you learning about?",
  'default': "That's an interesting question! Let me break this down step by step to help you understand better.\n\n1. First, let's identify the key concepts involved\n2. Then, we'll work through the problem together\n3. Finally, I'll provide some practice examples\n\nCould you share more details about what you're struggling with?"
};

export default function AiTutor() {
  const { theme } = useTheme();
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: "Hi! I'm your AI Study Buddy. I can help you understand difficult topics, answer homework questions, and explain concepts step-by-step. What would you like to learn about today?",
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [selectedSubject, setSelectedSubject] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const generateResponse = (userMessage: string): string => {
    const lowerMsg = userMessage.toLowerCase();
    if (lowerMsg.includes('math') || lowerMsg.includes('algebra') || lowerMsg.includes('calculus')) {
      return sampleResponses.math;
    }
    if (lowerMsg.includes('science') || lowerMsg.includes('physics') || lowerMsg.includes('chemistry')) {
      return sampleResponses.science;
    }
    if (lowerMsg.includes('history')) {
      return sampleResponses.history;
    }
    return sampleResponses.default;
  };

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    // Simulate AI response
    setTimeout(() => {
      const response = generateResponse(userMessage.content);
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response,
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, assistantMessage]);
      setIsTyping(false);
    }, 1500);
  };

  const handleSubjectClick = (subjectName: string) => {
    setSelectedSubject(subjectName);
    const message = `I'd like to learn about ${subjectName}`;
    setInput(message);
  };

  return (
    <div className={`min-h-screen flex flex-col ${theme === 'dark' ? 'bg-[#0B0B0D]' : 'bg-gray-50'} transition-colors`}>
      {/* Header */}
      <header className={`${theme === 'dark' ? 'bg-[#0B0B0D]/90' : 'bg-white/90'} backdrop-blur-md border-b ${theme === 'dark' ? 'border-white/10' : 'border-gray-200'} sticky top-0 z-40`}>
        <div className="px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center gap-4">
            <Link 
              to="/dashboard" 
              className={`p-2 rounded-xl ${theme === 'dark' ? 'bg-white/10 text-white' : 'bg-gray-100 text-gray-700'} hover:bg-lime hover:text-[#0B0B0D] transition-colors`}
            >
              <ArrowLeft className="w-5 h-5" />
            </Link>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-lime/20 flex items-center justify-center">
                <Bot className="w-6 h-6 text-lime" />
              </div>
              <div>
                <h1 className={`font-display font-bold text-xl ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                  AI Study Tutor
                </h1>
                <p className={`text-sm ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-500'}`}>
                  Always here to help
                </p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Subject Selector */}
      <div className={`px-4 sm:px-6 lg:px-8 py-4 border-b ${theme === 'dark' ? 'border-white/10' : 'border-gray-200'}`}>
        <p className={`text-sm mb-3 ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-500'}`}>
          Select a subject or ask anything:
        </p>
        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
          {subjects.map((subject, i) => (
            <button
              key={i}
              onClick={() => handleSubjectClick(subject.name)}
              className={`flex items-center gap-2 px-4 py-2 rounded-full whitespace-nowrap transition-colors ${
                selectedSubject === subject.name
                  ? 'bg-lime text-[#0B0B0D]'
                  : `${subject.color} hover:opacity-80`
              }`}
            >
              <subject.icon className="w-4 h-4" />
              <span className="text-sm font-medium">{subject.name}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="max-w-4xl mx-auto space-y-6">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex gap-4 ${message.role === 'user' ? 'flex-row-reverse' : ''}`}
            >
              <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${
                message.role === 'user'
                  ? 'bg-violet/20'
                  : 'bg-lime/20'
              }`}>
                {message.role === 'user' ? (
                  <User className="w-5 h-5 text-violet" />
                ) : (
                  <Bot className="w-5 h-5 text-lime" />
                )}
              </div>
              <div className={`max-w-[80%] ${message.role === 'user' ? 'text-right' : ''}`}>
                <div
                  className={`inline-block px-5 py-3 rounded-2xl text-left ${
                    message.role === 'user'
                      ? 'bg-violet text-white'
                      : theme === 'dark'
                        ? 'bg-white/[0.08] text-white'
                        : 'bg-white text-gray-900 shadow-sm'
                  }`}
                >
                  <p className="whitespace-pre-line">{message.content}</p>
                </div>
                <p className={`text-xs mt-1 ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-500'}`}>
                  {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </p>
              </div>
            </div>
          ))}
          
          {isTyping && (
            <div className="flex gap-4">
              <div className="w-10 h-10 rounded-full bg-lime/20 flex items-center justify-center">
                <Bot className="w-5 h-5 text-lime" />
              </div>
              <div className={`px-5 py-3 rounded-2xl ${theme === 'dark' ? 'bg-white/[0.08]' : 'bg-white shadow-sm'}`}>
                <div className="flex gap-1">
                  <span className="w-2 h-2 bg-lime rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                  <span className="w-2 h-2 bg-lime rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                  <span className="w-2 h-2 bg-lime rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Input */}
      <div className={`px-4 sm:px-6 lg:px-8 py-4 border-t ${theme === 'dark' ? 'border-white/10' : 'border-gray-200'}`}>
        <div className="max-w-4xl mx-auto">
          <div className={`flex items-center gap-3 p-2 rounded-2xl ${theme === 'dark' ? 'bg-white/[0.06]' : 'bg-white shadow-sm'}`}>
            <Sparkles className={`w-5 h-5 ml-3 ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-400'}`} />
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Ask me anything about your studies..."
              className={`flex-1 bg-transparent px-3 py-3 outline-none ${theme === 'dark' ? 'text-white placeholder:text-[#A7A7AD]' : 'text-gray-900 placeholder:text-gray-400'}`}
            />
            <button
              onClick={handleSend}
              disabled={!input.trim() || isTyping}
              className="p-3 bg-lime rounded-xl text-[#0B0B0D] hover:scale-105 transition-transform disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
          <p className={`text-xs text-center mt-3 ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-500'}`}>
            AI Tutor can make mistakes. Always verify important information.
          </p>
        </div>
      </div>
    </div>
  );
}
