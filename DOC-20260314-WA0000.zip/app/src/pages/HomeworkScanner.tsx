import { useState, useRef } from 'react';
import { Link } from 'react-router-dom';
import { 
  ArrowLeft, Camera, Upload, CheckCircle, 
  Sparkles, Calculator, Lightbulb, RotateCcw
} from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';

interface ScannedProblem {
  id: string;
  image: string;
  detectedText: string;
  solution: string;
  steps: string[];
  explanation: string;
}

export default function HomeworkScanner() {
  const { theme } = useTheme();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [scannedProblem, setScannedProblem] = useState<ScannedProblem | null>(null);
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      handleFile(files[0]);
    }
  };

  const handleFile = (file: File) => {
    if (file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setUploadedImage(e.target?.result as string);
        processImage();
      };
      reader.readAsDataURL(file);
    }
  };

  const processImage = () => {
    setIsScanning(true);
    
    // Simulate AI processing
    setTimeout(() => {
      const mockProblem: ScannedProblem = {
        id: Date.now().toString(),
        image: uploadedImage || '',
        detectedText: 'Solve for x: 2x + 5 = 15',
        solution: 'x = 5',
        steps: [
          'Start with the equation: 2x + 5 = 15',
          'Subtract 5 from both sides: 2x = 10',
          'Divide both sides by 2: x = 5',
        ],
        explanation: 'This is a linear equation. To solve for x, we isolate the variable by performing inverse operations. First, we subtract the constant term, then divide by the coefficient of x.',
      };
      setScannedProblem(mockProblem);
      setIsScanning(false);
    }, 2500);
  };

  const resetScanner = () => {
    setScannedProblem(null);
    setUploadedImage(null);
  };

  return (
    <div className={`min-h-screen ${theme === 'dark' ? 'bg-[#0B0B0D]' : 'bg-gray-50'} transition-colors`}>
      {/* Header */}
      <header className={`${theme === 'dark' ? 'bg-[#0B0B0D]/90' : 'bg-white/90'} backdrop-blur-md border-b ${theme === 'dark' ? 'border-white/10' : 'border-gray-200'} sticky top-0 z-40`}>
        <div className="px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center gap-4">
            <Link 
              to="/dashboard" 
              className={`p-2 rounded-xl ${theme === 'dark' ? 'bg-white/10 text-white' : 'bg-gray-100 text-gray-700'} hover:bg-lime hover:text-[#0B0B0D] transition-colors`}
            >
              <ArrowLeft className="w-5 h-5" />
            </Link>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-violet/20 flex items-center justify-center">
                <Camera className="w-6 h-6 text-violet" />
              </div>
              <div>
                <h1 className={`font-display font-bold text-xl ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                  AI Homework Scanner
                </h1>
                <p className={`text-sm ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-500'}`}>
                  Scan and solve problems instantly
                </p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="px-4 sm:px-6 lg:px-8 py-8">
        <div className="max-w-4xl mx-auto">
          {!scannedProblem ? (
            /* Upload Section */
            <div className={`neon-card p-8 ${theme === 'light' ? 'bg-white' : ''}`}>
              <div className="text-center mb-8">
                <div className="w-20 h-20 rounded-full bg-lime/20 flex items-center justify-center mx-auto mb-4">
                  <Upload className="w-10 h-10 text-lime" />
                </div>
                <h2 className={`font-display font-bold text-2xl mb-2 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                  Upload Your Homework
                </h2>
                <p className={theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-600'}>
                  Take a photo or upload an image of your problem
                </p>
              </div>

              {/* Upload Area */}
              <div
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
                className={`border-2 border-dashed rounded-2xl p-12 text-center cursor-pointer transition-colors ${
                  isDragging
                    ? 'border-lime bg-lime/10'
                    : theme === 'dark'
                      ? 'border-white/20 hover:border-white/40'
                      : 'border-gray-300 hover:border-gray-400'
                }`}
              >
                {uploadedImage ? (
                  <img
                    src={uploadedImage}
                    alt="Uploaded homework"
                    className="max-h-64 mx-auto rounded-xl"
                  />
                ) : (
                  <>
                    <Camera className={`w-12 h-12 mx-auto mb-4 ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-400'}`} />
                    <p className={`font-medium mb-2 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                      Drag & drop or click to upload
                    </p>
                    <p className={`text-sm ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-500'}`}>
                      Supports JPG, PNG (max 10MB)
                    </p>
                  </>
                )}
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
                  className="hidden"
                />
              </div>

              {/* Supported Types */}
              <div className="mt-8">
                <p className={`text-sm font-medium mb-4 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                  Works great with:
                </p>
                <div className="flex flex-wrap gap-3">
                  {['Math Problems', 'Science Questions', 'Textbook Exercises', 'Equations', 'Word Problems'].map((type) => (
                    <span
                      key={type}
                      className={`px-4 py-2 rounded-full text-sm ${theme === 'dark' ? 'bg-white/[0.06] text-[#A7A7AD]' : 'bg-gray-100 text-gray-600'}`}
                    >
                      {type}
                    </span>
                  ))}
                </div>
              </div>

              {/* Scan Button */}
              {uploadedImage && (
                <button
                  onClick={processImage}
                  disabled={isScanning}
                  className="w-full mt-8 btn-lime flex items-center justify-center gap-2 py-4 disabled:opacity-50"
                >
                  {isScanning ? (
                    <>
                      <div className="animate-spin rounded-full h-5 w-5 border-t-2 border-b-2 border-[#0B0B0D]" />
                      Analyzing...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-5 h-5" />
                      Solve Problem
                    </>
                  )}
                </button>
              )}
            </div>
          ) : (
            /* Results Section */
            <div className="space-y-6">
              {/* Detected Problem */}
              <div className={`neon-card p-6 ${theme === 'light' ? 'bg-white' : ''}`}>
                <div className="flex items-center gap-3 mb-4">
                  <Camera className="w-5 h-5 text-lime" />
                  <h3 className={`font-semibold ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                    Detected Problem
                  </h3>
                </div>
                <div className={`p-4 rounded-xl ${theme === 'dark' ? 'bg-white/[0.06]' : 'bg-gray-50'}`}>
                  <p className={`text-lg font-mono ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                    {scannedProblem.detectedText}
                  </p>
                </div>
              </div>

              {/* Solution */}
              <div className={`neon-card p-6 ${theme === 'light' ? 'bg-white' : ''}`}>
                <div className="flex items-center gap-3 mb-4">
                  <CheckCircle className="w-5 h-5 text-green-400" />
                  <h3 className={`font-semibold ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                    Solution
                  </h3>
                </div>
                <div className="p-4 rounded-xl bg-lime/10 border border-lime/30">
                  <p className="text-2xl font-bold text-lime">
                    {scannedProblem.solution}
                  </p>
                </div>
              </div>

              {/* Step-by-Step */}
              <div className={`neon-card p-6 ${theme === 'light' ? 'bg-white' : ''}`}>
                <div className="flex items-center gap-3 mb-4">
                  <Calculator className="w-5 h-5 text-violet" />
                  <h3 className={`font-semibold ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                    Step-by-Step Solution
                  </h3>
                </div>
                <div className="space-y-4">
                  {scannedProblem.steps.map((step, i) => (
                    <div
                      key={i}
                      className={`flex items-start gap-4 p-4 rounded-xl ${theme === 'dark' ? 'bg-white/[0.04]' : 'bg-gray-50'}`}
                    >
                      <div className="w-8 h-8 rounded-full bg-violet/20 flex items-center justify-center flex-shrink-0">
                        <span className="text-violet font-bold text-sm">{i + 1}</span>
                      </div>
                      <p className={`${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>{step}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Explanation */}
              <div className={`neon-card p-6 ${theme === 'light' ? 'bg-white' : ''}`}>
                <div className="flex items-center gap-3 mb-4">
                  <Lightbulb className="w-5 h-5 text-yellow-400" />
                  <h3 className={`font-semibold ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                    Why This Works
                  </h3>
                </div>
                <p className={`${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-600'} leading-relaxed`}>
                  {scannedProblem.explanation}
                </p>
              </div>

              {/* Actions */}
              <div className="flex gap-4">
                <button
                  onClick={resetScanner}
                  className="flex-1 btn-lime flex items-center justify-center gap-2 py-4"
                >
                  <RotateCcw className="w-5 h-5" />
                  Scan Another
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
