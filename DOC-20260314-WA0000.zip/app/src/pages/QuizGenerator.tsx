import { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  ArrowLeft, HelpCircle, Sparkles, CheckCircle, XCircle, 
  Trophy, Clock, BookOpen, Target, ChevronRight, RotateCcw
} from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';

interface Question {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

interface QuizResult {
  score: number;
  total: number;
  correct: number;
  incorrect: number;
  weakAreas: string[];
}

const sampleQuestions: Question[] = [
  {
    id: 1,
    question: "What is the powerhouse of the cell?",
    options: ["Nucleus", "Mitochondria", "Ribosome", "Endoplasmic Reticulum"],
    correctAnswer: 1,
    explanation: "Mitochondria are often called the powerhouse of the cell because they generate most of the cell's supply of adenosine triphosphate (ATP)."
  },
  {
    id: 2,
    question: "What is the value of π (pi) to two decimal places?",
    options: ["3.12", "3.14", "3.16", "3.18"],
    correctAnswer: 1,
    explanation: "Pi (π) is approximately equal to 3.14159..., so to two decimal places it is 3.14."
  },
  {
    id: 3,
    question: "Which planet is known as the Red Planet?",
    options: ["Venus", "Jupiter", "Mars", "Saturn"],
    correctAnswer: 2,
    explanation: "Mars is called the Red Planet because of its reddish appearance, caused by iron oxide (rust) on its surface."
  },
  {
    id: 4,
    question: "What is the chemical formula for water?",
    options: ["CO2", "H2O", "NaCl", "O2"],
    correctAnswer: 1,
    explanation: "Water is composed of two hydrogen atoms and one oxygen atom, giving it the chemical formula H2O."
  },
  {
    id: 5,
    question: "Who wrote 'Romeo and Juliet'?",
    options: ["Charles Dickens", "William Shakespeare", "Jane Austen", "Mark Twain"],
    correctAnswer: 1,
    explanation: "William Shakespeare wrote the famous tragedy 'Romeo and Juliet' around 1594-1596."
  }
];

export default function QuizGenerator() {
  const { theme } = useTheme();
  const [subject, setSubject] = useState('');
  const [difficulty, setDifficulty] = useState('medium');
  const [quizType, setQuizType] = useState('multiple');
  const [isGenerating, setIsGenerating] = useState(false);
  const [quizStarted, setQuizStarted] = useState(false);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [answers, setAnswers] = useState<number[]>([]);
  const [showExplanation, setShowExplanation] = useState(false);
  const [quizCompleted, setQuizCompleted] = useState(false);

  const handleGenerate = async () => {
    if (!subject.trim()) return;
    setIsGenerating(true);
    
    setTimeout(() => {
      setIsGenerating(false);
      setQuizStarted(true);
    }, 1500);
  };

  const handleAnswer = (answerIndex: number) => {
    setSelectedAnswer(answerIndex);
    setShowExplanation(true);
  };

  const handleNext = () => {
    if (selectedAnswer !== null) {
      setAnswers([...answers, selectedAnswer]);
    }
    
    if (currentQuestion < sampleQuestions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
      setShowExplanation(false);
    } else {
      setQuizCompleted(true);
    }
  };

  const calculateResult = (): QuizResult => {
    let correct = 0;
    answers.forEach((answer, index) => {
      if (answer === sampleQuestions[index].correctAnswer) {
        correct++;
      }
    });
    
    return {
      score: Math.round((correct / sampleQuestions.length) * 100),
      total: sampleQuestions.length,
      correct,
      incorrect: sampleQuestions.length - correct,
      weakAreas: correct < sampleQuestions.length ? ['General Knowledge'] : []
    };
  };

  const resetQuiz = () => {
    setQuizStarted(false);
    setQuizCompleted(false);
    setCurrentQuestion(0);
    setSelectedAnswer(null);
    setAnswers([]);
    setShowExplanation(false);
    setSubject('');
  };

  const result = quizCompleted ? calculateResult() : null;

  return (
    <div className={`min-h-screen ${theme === 'dark' ? 'bg-[#0B0B0D]' : 'bg-gray-50'} transition-colors`}>
      {/* Header */}
      <header className={`${theme === 'dark' ? 'bg-[#0B0B0D]/90' : 'bg-white/90'} backdrop-blur-md border-b ${theme === 'dark' ? 'border-white/10' : 'border-gray-200'} sticky top-0 z-40`}>
        <div className="px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center gap-4">
            <Link 
              to="/dashboard" 
              className={`p-2 rounded-xl ${theme === 'dark' ? 'bg-white/10 text-white' : 'bg-gray-100 text-gray-700'} hover:bg-lime hover:text-[#0B0B0D] transition-colors`}
            >
              <ArrowLeft className="w-5 h-5" />
            </Link>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-lime/20 flex items-center justify-center">
                <HelpCircle className="w-6 h-6 text-lime" />
              </div>
              <div>
                <h1 className={`font-display font-bold text-xl ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                  AI Quiz Generator
                </h1>
                <p className={`text-sm ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-500'}`}>
                  Test your knowledge
                </p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="px-4 sm:px-6 lg:px-8 py-8">
        <div className="max-w-3xl mx-auto">
          {!quizStarted ? (
            /* Quiz Setup */
            <div className={`neon-card p-8 ${theme === 'light' ? 'bg-white' : ''}`}>
              <div className="text-center mb-8">
                <Target className="w-16 h-16 text-lime mx-auto mb-4" />
                <h2 className={`font-display font-bold text-2xl mb-2 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                  Generate a Quiz
                </h2>
                <p className={theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-600'}>
                  Choose your subject and difficulty level
                </p>
              </div>

              <div className="space-y-6">
                {/* Subject Input */}
                <div>
                  <label className={`block text-sm font-medium mb-2 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                    Subject / Topic
                  </label>
                  <input
                    type="text"
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    placeholder="e.g., Biology, World History, Algebra..."
                    className={`w-full px-4 py-3 rounded-xl border-2 transition-colors ${
                      theme === 'dark'
                        ? 'bg-white/[0.06] border-white/[0.2] text-white placeholder:text-[#A7A7AD] focus:border-lime'
                        : 'bg-gray-50 border-gray-200 text-gray-900 placeholder:text-gray-400 focus:border-lime'
                    }`}
                  />
                </div>

                {/* Difficulty */}
                <div>
                  <label className={`block text-sm font-medium mb-2 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                    Difficulty Level
                  </label>
                  <div className="grid grid-cols-3 gap-3">
                    {['easy', 'medium', 'hard'].map((level) => (
                      <button
                        key={level}
                        onClick={() => setDifficulty(level)}
                        className={`py-3 rounded-xl border-2 capitalize transition-colors ${
                          difficulty === level
                            ? 'border-lime bg-lime/10 text-lime'
                            : theme === 'dark'
                              ? 'border-white/10 text-white hover:border-white/30'
                              : 'border-gray-200 text-gray-700 hover:border-gray-300'
                        }`}
                      >
                        {level}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Quiz Type */}
                <div>
                  <label className={`block text-sm font-medium mb-2 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                    Question Type
                  </label>
                  <div className="grid grid-cols-2 gap-3">
                    {[
                      { id: 'multiple', label: 'Multiple Choice' },
                      { id: 'truefalse', label: 'True / False' },
                    ].map((type) => (
                      <button
                        key={type.id}
                        onClick={() => setQuizType(type.id)}
                        className={`py-3 rounded-xl border-2 transition-colors ${
                          quizType === type.id
                            ? 'border-lime bg-lime/10 text-lime'
                            : theme === 'dark'
                              ? 'border-white/10 text-white hover:border-white/30'
                              : 'border-gray-200 text-gray-700 hover:border-gray-300'
                        }`}
                      >
                        {type.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Generate Button */}
                <button
                  onClick={handleGenerate}
                  disabled={!subject.trim() || isGenerating}
                  className="w-full btn-lime flex items-center justify-center gap-2 py-4 disabled:opacity-50"
                >
                  {isGenerating ? (
                    <>
                      <div className="animate-spin rounded-full h-5 w-5 border-t-2 border-b-2 border-[#0B0B0D]" />
                      Generating Quiz...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-5 h-5" />
                      Start Quiz
                    </>
                  )}
                </button>
              </div>
            </div>
          ) : quizCompleted ? (
            /* Quiz Results */
            <div className={`neon-card p-8 ${theme === 'light' ? 'bg-white' : ''}`}>
              <div className="text-center mb-8">
                <Trophy className="w-20 h-20 text-lime mx-auto mb-4" />
                <h2 className={`font-display font-bold text-3xl mb-2 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                  Quiz Complete!
                </h2>
                <p className={theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-600'}>
                  Here's how you performed
                </p>
              </div>

              <div className="grid grid-cols-3 gap-4 mb-8">
                <div className={`text-center p-4 rounded-xl ${theme === 'dark' ? 'bg-white/[0.06]' : 'bg-gray-50'}`}>
                  <p className="text-3xl font-bold text-lime">{result?.score}%</p>
                  <p className={`text-sm ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-500'}`}>Score</p>
                </div>
                <div className={`text-center p-4 rounded-xl ${theme === 'dark' ? 'bg-white/[0.06]' : 'bg-gray-50'}`}>
                  <p className="text-3xl font-bold text-green-400">{result?.correct}</p>
                  <p className={`text-sm ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-500'}`}>Correct</p>
                </div>
                <div className={`text-center p-4 rounded-xl ${theme === 'dark' ? 'bg-white/[0.06]' : 'bg-gray-50'}`}>
                  <p className="text-3xl font-bold text-red-400">{result?.incorrect}</p>
                  <p className={`text-sm ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-500'}`}>Incorrect</p>
                </div>
              </div>

              {result && result.weakAreas.length > 0 && (
                <div className={`mb-8 p-4 rounded-xl ${theme === 'dark' ? 'bg-violet/10' : 'bg-violet/5'}`}>
                  <p className={`font-semibold mb-2 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                    Areas to Review
                  </p>
                  <ul className="space-y-1">
                    {result.weakAreas.map((area, i) => (
                      <li key={i} className="flex items-center gap-2 text-violet text-sm">
                        <BookOpen className="w-4 h-4" />
                        {area}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              <button
                onClick={resetQuiz}
                className="w-full btn-lime flex items-center justify-center gap-2 py-4"
              >
                <RotateCcw className="w-5 h-5" />
                Try Another Quiz
              </button>
            </div>
          ) : (
            /* Quiz In Progress */
            <div className={`neon-card p-8 ${theme === 'light' ? 'bg-white' : ''}`}>
              {/* Progress */}
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-2">
                  <Clock className="w-5 h-5 text-lime" />
                  <span className={theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-500'}>
                    Question {currentQuestion + 1} of {sampleQuestions.length}
                  </span>
                </div>
                <div className="flex-1 mx-4 h-2 bg-white/10 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-lime rounded-full transition-all"
                    style={{ width: `${((currentQuestion + 1) / sampleQuestions.length) * 100}%` }}
                  />
                </div>
              </div>

              {/* Question */}
              <div className="mb-8">
                <h3 className={`font-display font-bold text-xl mb-6 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                  {sampleQuestions[currentQuestion].question}
                </h3>

                <div className="space-y-3">
                  {sampleQuestions[currentQuestion].options.map((option, i) => (
                    <button
                      key={i}
                      onClick={() => handleAnswer(i)}
                      disabled={showExplanation}
                      className={`w-full p-4 rounded-xl border-2 text-left transition-all ${
                        showExplanation
                          ? i === sampleQuestions[currentQuestion].correctAnswer
                            ? 'border-green-500 bg-green-500/10'
                            : selectedAnswer === i
                              ? 'border-red-500 bg-red-500/10'
                              : theme === 'dark'
                                ? 'border-white/10 opacity-50'
                                : 'border-gray-200 opacity-50'
                          : selectedAnswer === i
                            ? 'border-lime bg-lime/10'
                            : theme === 'dark'
                              ? 'border-white/10 hover:border-white/30'
                              : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        {showExplanation && i === sampleQuestions[currentQuestion].correctAnswer && (
                          <CheckCircle className="w-5 h-5 text-green-500" />
                        )}
                        {showExplanation && selectedAnswer === i && i !== sampleQuestions[currentQuestion].correctAnswer && (
                          <XCircle className="w-5 h-5 text-red-500" />
                        )}
                        <span className={theme === 'dark' ? 'text-white' : 'text-gray-900'}>{option}</span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Explanation */}
              {showExplanation && (
                <div className={`mb-6 p-4 rounded-xl ${theme === 'dark' ? 'bg-violet/10' : 'bg-violet/5'}`}>
                  <p className={`font-semibold mb-2 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                    Explanation
                  </p>
                  <p className={theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-600'}>
                    {sampleQuestions[currentQuestion].explanation}
                  </p>
                </div>
              )}

              {/* Next Button */}
              {showExplanation && (
                <button
                  onClick={handleNext}
                  className="w-full btn-lime flex items-center justify-center gap-2 py-4"
                >
                  {currentQuestion < sampleQuestions.length - 1 ? (
                    <>
                      Next Question
                      <ChevronRight className="w-5 h-5" />
                    </>
                  ) : (
                    'See Results'
                  )}
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
