import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, TrendingUp, Calendar, Target, Award, BookOpen } from 'lucide-react';
import { 
  LineChart, Line, XAxis, YAxis, CartesianGrid, 
  Tooltip, ResponsiveContainer, PieChart, Pie, Cell, AreaChart, Area 
} from 'recharts';
import { useTheme } from '../contexts/ThemeContext';
import { useAuth } from '../contexts/AuthContext';

const weeklyData = [
  { day: 'Mon', hours: 2.5, tasks: 4 },
  { day: 'Tue', hours: 3.0, tasks: 5 },
  { day: 'Wed', hours: 1.5, tasks: 3 },
  { day: 'Thu', hours: 4.0, tasks: 6 },
  { day: 'Fri', hours: 2.0, tasks: 4 },
  { day: 'Sat', hours: 5.0, tasks: 8 },
  { day: 'Sun', hours: 3.5, tasks: 5 },
];

const monthlyData = [
  { week: 'Week 1', score: 75 },
  { week: 'Week 2', score: 82 },
  { week: 'Week 3', score: 78 },
  { week: 'Week 4', score: 88 },
];

const subjectData = [
  { name: 'Mathematics', value: 35, color: '#B8FF2C' },
  { name: 'Science', value: 25, color: '#6B2CFF' },
  { name: 'History', value: 20, color: '#3B82F6' },
  { name: 'Languages', value: 15, color: '#F59E0B' },
  { name: 'Other', value: 5, color: '#EF4444' },
];

const weakAreas = [
  { subject: 'Calculus', progress: 45, total: 100 },
  { subject: 'Organic Chemistry', progress: 60, total: 100 },
  { subject: 'World History', progress: 70, total: 100 },
];

export default function ProgressTracking() {
  const { theme } = useTheme();
  const { user } = useAuth();
  const [timeRange] = useState('week');

  const stats = [
    { label: 'Total Study Hours', value: '156.5', icon: Calendar, change: '+12%', color: 'text-lime' },
    { label: 'Quizzes Completed', value: '42', icon: Target, change: '+8', color: 'text-violet' },
    { label: 'Average Score', value: '82%', icon: TrendingUp, change: '+5%', color: 'text-green-400' },
    { label: 'Current Streak', value: `${user?.streak || 0} days`, icon: Award, change: 'Best: 15', color: 'text-orange-400' },
  ];

  return (
    <div className={`min-h-screen ${theme === 'dark' ? 'bg-[#0B0B0D]' : 'bg-gray-50'} transition-colors`}>
      {/* Header */}
      <header className={`${theme === 'dark' ? 'bg-[#0B0B0D]/90' : 'bg-white/90'} backdrop-blur-md border-b ${theme === 'dark' ? 'border-white/10' : 'border-gray-200'} sticky top-0 z-40`}>
        <div className="px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center gap-4">
            <Link 
              to="/dashboard" 
              className={`p-2 rounded-xl ${theme === 'dark' ? 'bg-white/10 text-white' : 'bg-gray-100 text-gray-700'} hover:bg-lime hover:text-[#0B0B0D] transition-colors`}
            >
              <ArrowLeft className="w-5 h-5" />
            </Link>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-lime/20 flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-lime" />
              </div>
              <div>
                <h1 className={`font-display font-bold text-xl ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                  Progress Tracking
                </h1>
                <p className={`text-sm ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-500'}`}>
                  Monitor your learning journey
                </p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="px-4 sm:px-6 lg:px-8 py-8">
        <div className="max-w-7xl mx-auto">
          {/* Stats Grid */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            {stats.map((stat, i) => (
              <div key={i} className={`neon-card p-5 ${theme === 'light' ? 'bg-white' : ''}`}>
                <div className="flex items-center justify-between mb-3">
                  <stat.icon className={`w-6 h-6 ${stat.color}`} />
                  <span className="text-xs text-green-400">{stat.change}</span>
                </div>
                <p className={`text-2xl font-bold ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                  {stat.value}
                </p>
                <p className={`text-sm ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-500'}`}>
                  {stat.label}
                </p>
              </div>
            ))}
          </div>

          {/* Charts Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            {/* Study Hours Chart */}
            <div className={`neon-card p-6 ${theme === 'light' ? 'bg-white' : ''}`}>
              <div className="flex items-center justify-between mb-6">
                <h3 className={`font-semibold mb-6 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                  Study Hours This Week
                </h3>
                <div className="flex gap-2">
                  {['week', 'month'].map((range) => (
                    <button
                      key={range}
                      className={`px-3 py-1 rounded-lg text-sm capitalize transition-colors ${
                        timeRange === range
                          ? 'bg-lime text-[#0B0B0D]'
                          : theme === 'dark'
                            ? 'bg-white/10 text-white'
                            : 'bg-gray-100 text-gray-700'
                      }`}
                    >
                      {range}
                    </button>
                  ))}
                </div>
              </div>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={weeklyData}>
                    <defs>
                      <linearGradient id="colorHours" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#B8FF2C" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="#B8FF2C" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke={theme === 'dark' ? 'rgba(255,255,255,0.1)' : '#e5e7eb'} />
                    <XAxis dataKey="day" stroke={theme === 'dark' ? '#A7A7AD' : '#6b7280'} />
                    <YAxis stroke={theme === 'dark' ? '#A7A7AD' : '#6b7280'} />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: theme === 'dark' ? '#1a1a1a' : '#fff',
                        border: `1px solid ${theme === 'dark' ? 'rgba(255,255,255,0.1)' : '#e5e7eb'}`,
                        borderRadius: '12px'
                      }}
                    />
                    <Area 
                      type="monotone" 
                      dataKey="hours" 
                      stroke="#B8FF2C" 
                      fillOpacity={1} 
                      fill="url(#colorHours)" 
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Quiz Scores Chart */}
            <div className={`neon-card p-6 ${theme === 'light' ? 'bg-white' : ''}`}>
              <h3 className={`font-semibold mb-6 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                Quiz Performance
              </h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={monthlyData}>
                    <CartesianGrid strokeDasharray="3 3" stroke={theme === 'dark' ? 'rgba(255,255,255,0.1)' : '#e5e7eb'} />
                    <XAxis dataKey="week" stroke={theme === 'dark' ? '#A7A7AD' : '#6b7280'} />
                    <YAxis domain={[0, 100]} stroke={theme === 'dark' ? '#A7A7AD' : '#6b7280'} />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: theme === 'dark' ? '#1a1a1a' : '#fff',
                        border: `1px solid ${theme === 'dark' ? 'rgba(255,255,255,0.1)' : '#e5e7eb'}`,
                        borderRadius: '12px'
                      }}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="score" 
                      stroke="#6B2CFF" 
                      strokeWidth={3}
                      dot={{ fill: '#6B2CFF', strokeWidth: 2 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Subject Distribution */}
            <div className={`neon-card p-6 ${theme === 'light' ? 'bg-white' : ''}`}>
              <h3 className={`font-semibold mb-6 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                Time by Subject
              </h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={subjectData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {subjectData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: theme === 'dark' ? '#1a1a1a' : '#fff',
                        border: `1px solid ${theme === 'dark' ? 'rgba(255,255,255,0.1)' : '#e5e7eb'}`,
                        borderRadius: '12px'
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="flex flex-wrap justify-center gap-3 mt-4">
                {subjectData.map((subject) => (
                  <div key={subject.name} className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: subject.color }} />
                    <span className={`text-sm ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-600'}`}>
                      {subject.name}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Weak Areas */}
            <div className={`neon-card p-6 ${theme === 'light' ? 'bg-white' : ''}`}>
              <div className="flex items-center gap-3 mb-6">
                <BookOpen className="w-5 h-5 text-violet" />
                <h3 className={`font-semibold ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                  Areas to Improve
                </h3>
              </div>
              <div className="space-y-5">
                {weakAreas.map((area, i) => (
                  <div key={i}>
                    <div className="flex justify-between text-sm mb-2">
                      <span className={theme === 'dark' ? 'text-white' : 'text-gray-900'}>{area.subject}</span>
                      <span className="text-violet">{area.progress}%</span>
                    </div>
                    <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-violet rounded-full transition-all"
                        style={{ width: `${area.progress}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
              <div className={`mt-6 p-4 rounded-xl ${theme === 'dark' ? 'bg-violet/10' : 'bg-violet/5'}`}>
                <p className={`text-sm ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-600'}`}>
                  Focus on these topics to improve your overall performance. 
                  We recommend spending extra time on Calculus this week.
                </p>
              </div>
            </div>
          </div>

          {/* Weekly Report */}
          <div className={`neon-card p-6 ${theme === 'light' ? 'bg-white' : ''}`}>
            <h3 className={`font-semibold mb-4 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
              This Week's Achievements
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {[
                { label: 'Study Sessions', value: '12', subtext: '2 more than last week' },
                { label: 'Tasks Completed', value: '35', subtext: '85% completion rate' },
                { label: 'Focus Time', value: '21.5h', subtext: 'Above your average' },
              ].map((item, i) => (
                <div key={i} className={`p-4 rounded-xl ${theme === 'dark' ? 'bg-white/[0.04]' : 'bg-gray-50'}`}>
                  <p className={`text-2xl font-bold text-lime mb-1`}>{item.value}</p>
                  <p className={`font-medium ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>{item.label}</p>
                  <p className={`text-sm ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-500'}`}>{item.subtext}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
