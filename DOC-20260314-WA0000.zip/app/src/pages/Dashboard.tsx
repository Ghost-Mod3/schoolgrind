import { Link } from 'react-router-dom';
import { 
  MessageSquare, FileText, HelpCircle, Camera, 
  BarChart3, BookOpen, Zap, Flame, Target,
  Calendar, Clock, CheckSquare, TrendingUp,
  Sun, Moon, LogOut
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';

export default function Dashboard() {
  const { user, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();

  const quickActions = [
    { icon: MessageSquare, label: 'AI Tutor', href: '/ai-tutor', color: 'bg-violet' },
    { icon: FileText, label: 'Study Notes', href: '/notes', color: 'bg-lime' },
    { icon: HelpCircle, label: 'Quiz', href: '/quiz', color: 'bg-violet' },
    { icon: Camera, label: 'Scanner', href: '/scanner', color: 'bg-lime' },
  ];

  const stats = [
    { label: 'Study Streak', value: user?.streak || 0, icon: Flame, color: 'text-orange-400' },
    { label: 'XP Points', value: user?.xp || 0, icon: Zap, color: 'text-lime' },
    { label: 'Tasks Done', value: 18, icon: CheckSquare, color: 'text-violet' },
    { label: 'Study Hours', value: '24.5', icon: Clock, color: 'text-blue-400' },
  ];

  const recentActivity = [
    { type: 'notes', text: 'Generated notes for Calculus', time: '2 hours ago' },
    { type: 'quiz', text: 'Completed Physics Quiz - 85%', time: '5 hours ago' },
    { type: 'tutor', text: 'Asked AI Tutor about Chemistry', time: 'Yesterday' },
    { type: 'scanner', text: 'Scanned Math homework', time: 'Yesterday' },
  ];

  const badges = user?.badges || ['quick_starter'];

  return (
    <div className={`min-h-screen ${theme === 'dark' ? 'bg-[#0B0B0D]' : 'bg-gray-50'} transition-colors`}>
      {/* Top Navigation */}
      <nav className={`${theme === 'dark' ? 'bg-[#0B0B0D]/90' : 'bg-white/90'} backdrop-blur-md border-b ${theme === 'dark' ? 'border-white/10' : 'border-gray-200'} sticky top-0 z-40`}>
        <div className="px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <Link to="/" className="text-lime font-display font-bold text-xl">
              SchoolGrind
            </Link>
            
            <div className="flex items-center gap-4">
              {/* Theme Toggle */}
              <button
                onClick={toggleTheme}
                className={`p-2 rounded-xl ${theme === 'dark' ? 'bg-white/10 text-white' : 'bg-gray-100 text-gray-700'} hover:bg-lime hover:text-[#0B0B0D] transition-colors`}
              >
                {theme === 'dark' ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
              </button>
              
              {/* User Profile */}
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-lime/20 flex items-center justify-center">
                  <span className="text-lime font-bold">
                    {user?.name?.charAt(0).toUpperCase() || 'U'}
                  </span>
                </div>
                <button
                  onClick={logout}
                  className={`p-2 rounded-xl ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-500'} hover:text-red-400 transition-colors`}
                >
                  <LogOut className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </nav>

      <div className="px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className={`font-display font-bold text-3xl mb-2 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
            Welcome back, {user?.name?.split(' ')[0] || 'Student'}! 👋
          </h1>
          <p className={theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-600'}>
            Ready to crush your study goals today?
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {stats.map((stat, i) => (
            <div key={i} className={`neon-card p-5 ${theme === 'light' ? 'bg-white' : ''}`}>
              <div className="flex items-center justify-between mb-3">
                <stat.icon className={`w-6 h-6 ${stat.color}`} />
                <TrendingUp className="w-4 h-4 text-lime" />
              </div>
              <p className={`text-2xl font-bold ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                {stat.value}
              </p>
              <p className={`text-sm ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-500'}`}>
                {stat.label}
              </p>
            </div>
          ))}
        </div>

        {/* Quick Actions */}
        <div className="mb-8">
          <h2 className={`font-display font-semibold text-xl mb-4 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
            Quick Actions
          </h2>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {quickActions.map((action, i) => (
              <Link
                key={i}
                to={action.href}
                className={`neon-card p-6 group hover:scale-[1.02] transition-transform ${theme === 'light' ? 'bg-white' : ''}`}
              >
                <div className={`w-12 h-12 rounded-xl ${action.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                  <action.icon className={`w-6 h-6 ${action.color === 'bg-lime' ? 'text-[#0B0B0D]' : 'text-white'}`} />
                </div>
                <p className={`font-semibold ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                  {action.label}
                </p>
              </Link>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Recent Activity */}
          <div className="lg:col-span-2">
            <div className={`neon-card p-6 ${theme === 'light' ? 'bg-white' : ''}`}>
              <h2 className={`font-display font-semibold text-xl mb-4 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                Recent Activity
              </h2>
              <div className="space-y-4">
                {recentActivity.map((activity, i) => (
                  <div
                    key={i}
                    className={`flex items-center gap-4 p-4 rounded-xl ${theme === 'dark' ? 'bg-white/[0.04]' : 'bg-gray-50'}`}
                  >
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                      activity.type === 'notes' ? 'bg-violet/20' :
                      activity.type === 'quiz' ? 'bg-lime/20' :
                      activity.type === 'tutor' ? 'bg-blue-500/20' :
                      'bg-orange-500/20'
                    }`}>
                      {activity.type === 'notes' && <FileText className="w-5 h-5 text-violet" />}
                      {activity.type === 'quiz' && <HelpCircle className="w-5 h-5 text-lime" />}
                      {activity.type === 'tutor' && <MessageSquare className="w-5 h-5 text-blue-400" />}
                      {activity.type === 'scanner' && <Camera className="w-5 h-5 text-orange-400" />}
                    </div>
                    <div className="flex-1">
                      <p className={`text-sm ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                        {activity.text}
                      </p>
                      <p className={`text-xs ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-500'}`}>
                        {activity.time}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Badges */}
            <div className={`neon-card p-6 ${theme === 'light' ? 'bg-white' : ''}`}>
              <h2 className={`font-display font-semibold text-xl mb-4 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                Your Badges
              </h2>
              <div className="flex flex-wrap gap-3">
                {badges.map((badge, i) => (
                  <div
                    key={i}
                    className="px-4 py-2 rounded-full bg-lime/20 text-lime text-sm font-medium flex items-center gap-2"
                  >
                    <Target className="w-4 h-4" />
                    {badge === 'quick_starter' ? 'Quick Starter' : 'Week Warrior'}
                  </div>
                ))}
              </div>
            </div>

            {/* Progress */}
            <Link to="/progress" className={`neon-card p-6 block hover:scale-[1.02] transition-transform ${theme === 'light' ? 'bg-white' : ''}`}>
              <div className="flex items-center justify-between mb-4">
                <h2 className={`font-display font-semibold text-xl ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                  Progress
                </h2>
                <BarChart3 className="w-5 h-5 text-lime" />
              </div>
              <div className="space-y-3">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className={theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-600'}>Weekly Goal</span>
                    <span className="text-lime">75%</span>
                  </div>
                  <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                    <div className="h-full w-3/4 bg-lime rounded-full" />
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className={theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-600'}>Monthly Goal</span>
                    <span className="text-violet">60%</span>
                  </div>
                  <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                    <div className="h-full w-3/5 bg-violet rounded-full" />
                  </div>
                </div>
              </div>
            </Link>

            {/* Study Library */}
            <Link to="/library" className={`neon-card p-6 block hover:scale-[1.02] transition-transform ${theme === 'light' ? 'bg-white' : ''}`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <BookOpen className="w-6 h-6 text-lime" />
                  <div>
                    <h2 className={`font-display font-semibold ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                      Study Library
                    </h2>
                    <p className={`text-sm ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-500'}`}>
                      12 saved items
                    </p>
                  </div>
                </div>
                <Calendar className="w-5 h-5 text-[#A7A7AD]" />
              </div>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
