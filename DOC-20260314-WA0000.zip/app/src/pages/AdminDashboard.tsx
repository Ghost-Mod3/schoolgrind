import { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  ArrowLeft, Users, Activity, FileText, HelpCircle, 
  Camera, Clock, BarChart3, TrendingUp, Search,
  Ban, CheckCircle, Shield
} from 'lucide-react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, 
  Tooltip, ResponsiveContainer, AreaChart, Area 
} from 'recharts';
import { useTheme } from '../contexts/ThemeContext';

// Mock analytics data
const dailyUsersData = [
  { date: 'Mon', users: 1200, active: 850 },
  { date: 'Tue', users: 1350, active: 920 },
  { date: 'Wed', users: 1180, active: 780 },
  { date: 'Thu', users: 1420, active: 980 },
  { date: 'Fri', users: 1500, active: 1100 },
  { date: 'Sat', users: 1800, active: 1350 },
  { date: 'Sun', users: 1650, active: 1200 },
];

const featureUsageData = [
  { feature: 'AI Tutor', usage: 4500 },
  { feature: 'Notes', usage: 3200 },
  { feature: 'Quiz', usage: 2800 },
  { feature: 'Scanner', usage: 1900 },
];

const recentUsers = [
  { id: '1', name: 'Alice Johnson', email: 'alice@school.edu', joined: '2026-03-13', status: 'active', xp: 1250 },
  { id: '2', name: 'Bob Smith', email: 'bob@school.edu', joined: '2026-03-12', status: 'active', xp: 890 },
  { id: '3', name: 'Carol White', email: 'carol@school.edu', joined: '2026-03-11', status: 'banned', xp: 0 },
  { id: '4', name: 'David Brown', email: 'david@school.edu', joined: '2026-03-10', status: 'active', xp: 2100 },
  { id: '5', name: 'Emma Davis', email: 'emma@school.edu', joined: '2026-03-09', status: 'active', xp: 1560 },
];

export default function AdminDashboard() {
  const { theme } = useTheme();
  const [activeTab, setActiveTab] = useState('overview');
  const [searchQuery, setSearchQuery] = useState('');
  const [users, setUsers] = useState(recentUsers);

  const stats = [
    { label: 'Total Users', value: '20,450', icon: Users, change: '+12%', color: 'text-lime' },
    { label: 'Daily Active', value: '8,230', icon: Activity, change: '+8%', color: 'text-violet' },
    { label: 'AI Questions', value: '45.2K', icon: FileText, change: '+23%', color: 'text-blue-400' },
    { label: 'Avg Study Time', value: '2.4h', icon: Clock, change: '+15%', color: 'text-orange-400' },
  ];

  const filteredUsers = users.filter(user => 
    user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    user.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const toggleUserStatus = (userId: string) => {
    setUsers(users.map(user => 
      user.id === userId 
        ? { ...user, status: user.status === 'active' ? 'banned' : 'active' }
        : user
    ));
  };

  return (
    <div className={`min-h-screen ${theme === 'dark' ? 'bg-[#0B0B0D]' : 'bg-gray-50'} transition-colors`}>
      {/* Header */}
      <header className={`${theme === 'dark' ? 'bg-[#0B0B0D]/90' : 'bg-white/90'} backdrop-blur-md border-b ${theme === 'dark' ? 'border-white/10' : 'border-gray-200'} sticky top-0 z-40`}>
        <div className="px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link 
                to="/dashboard" 
                className={`p-2 rounded-xl ${theme === 'dark' ? 'bg-white/10 text-white' : 'bg-gray-100 text-gray-700'} hover:bg-lime hover:text-[#0B0B0D] transition-colors`}
              >
                <ArrowLeft className="w-5 h-5" />
              </Link>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-red-500/20 flex items-center justify-center">
                  <Shield className="w-6 h-6 text-red-400" />
                </div>
                <div>
                  <h1 className={`font-display font-bold text-xl ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                    Admin Dashboard
                  </h1>
                  <p className={`text-sm ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-500'}`}>
                    Platform Analytics & Management
                  </p>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-red-500/20 text-red-400 text-sm">
              <Shield className="w-4 h-4" />
              Admin Access
            </div>
          </div>
        </div>
      </header>

      <div className="px-4 sm:px-6 lg:px-8 py-8">
        <div className="max-w-7xl mx-auto">
          {/* Tabs */}
          <div className="flex gap-2 mb-8 overflow-x-auto">
            {[
              { id: 'overview', label: 'Overview', icon: BarChart3 },
              { id: 'users', label: 'Users', icon: Users },
              { id: 'activity', label: 'Activity', icon: Activity },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-5 py-3 rounded-xl whitespace-nowrap transition-colors ${
                  activeTab === tab.id
                    ? 'bg-lime text-[#0B0B0D]'
                    : theme === 'dark'
                      ? 'bg-white/10 text-white hover:bg-white/20'
                      : 'bg-white text-gray-700 hover:bg-gray-100'
                }`}
              >
                <tab.icon className="w-5 h-5" />
                {tab.label}
              </button>
            ))}
          </div>

          {activeTab === 'overview' && (
            <div className="space-y-8">
              {/* Stats Grid */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                {stats.map((stat, i) => (
                  <div key={i} className={`neon-card p-5 ${theme === 'light' ? 'bg-white' : ''}`}>
                    <div className="flex items-center justify-between mb-3">
                      <stat.icon className={`w-6 h-6 ${stat.color}`} />
                      <span className="text-xs text-green-400">{stat.change}</span>
                    </div>
                    <p className={`text-2xl font-bold ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                      {stat.value}
                    </p>
                    <p className={`text-sm ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-500'}`}>
                      {stat.label}
                    </p>
                  </div>
                ))}
              </div>

              {/* Charts */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Daily Users */}
                <div className={`neon-card p-6 ${theme === 'light' ? 'bg-white' : ''}`}>
                  <h3 className={`font-semibold mb-6 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                    Daily Active Users
                  </h3>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={dailyUsersData}>
                        <defs>
                          <linearGradient id="colorUsers" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#B8FF2C" stopOpacity={0.3}/>
                            <stop offset="95%" stopColor="#B8FF2C" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke={theme === 'dark' ? 'rgba(255,255,255,0.1)' : '#e5e7eb'} />
                        <XAxis dataKey="date" stroke={theme === 'dark' ? '#A7A7AD' : '#6b7280'} />
                        <YAxis stroke={theme === 'dark' ? '#A7A7AD' : '#6b7280'} />
                        <Tooltip 
                          contentStyle={{ 
                            backgroundColor: theme === 'dark' ? '#1a1a1a' : '#fff',
                            border: `1px solid ${theme === 'dark' ? 'rgba(255,255,255,0.1)' : '#e5e7eb'}`,
                            borderRadius: '12px'
                          }}
                        />
                        <Area type="monotone" dataKey="users" stroke="#B8FF2C" fill="url(#colorUsers)" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* Feature Usage */}
                <div className={`neon-card p-6 ${theme === 'light' ? 'bg-white' : ''}`}>
                  <h3 className={`font-semibold mb-6 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                    Feature Usage
                  </h3>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={featureUsageData}>
                        <CartesianGrid strokeDasharray="3 3" stroke={theme === 'dark' ? 'rgba(255,255,255,0.1)' : '#e5e7eb'} />
                        <XAxis dataKey="feature" stroke={theme === 'dark' ? '#A7A7AD' : '#6b7280'} />
                        <YAxis stroke={theme === 'dark' ? '#A7A7AD' : '#6b7280'} />
                        <Tooltip 
                          contentStyle={{ 
                            backgroundColor: theme === 'dark' ? '#1a1a1a' : '#fff',
                            border: `1px solid ${theme === 'dark' ? 'rgba(255,255,255,0.1)' : '#e5e7eb'}`,
                            borderRadius: '12px'
                          }}
                        />
                        <Bar dataKey="usage" fill="#B8FF2C" radius={[8, 8, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>

              {/* Quick Stats */}
              <div className={`neon-card p-6 ${theme === 'light' ? 'bg-white' : ''}`}>
                <h3 className={`font-semibold mb-4 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                  Platform Activity (Last 24h)
                </h3>
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
                  {[
                    { label: 'Notes Generated', value: '1,240', icon: FileText },
                    { label: 'Quizzes Taken', value: '856', icon: HelpCircle },
                    { label: 'Homework Scans', value: '432', icon: Camera },
                    { label: 'New Signups', value: '127', icon: TrendingUp },
                  ].map((item, i) => (
                    <div key={i} className="flex items-center gap-4">
                      <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${theme === 'dark' ? 'bg-white/10' : 'bg-gray-100'}`}>
                        <item.icon className="w-6 h-6 text-lime" />
                      </div>
                      <div>
                        <p className={`text-2xl font-bold ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                          {item.value}
                        </p>
                        <p className={`text-sm ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-500'}`}>
                          {item.label}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'users' && (
            <div className={`neon-card ${theme === 'light' ? 'bg-white' : ''}`}>
              {/* Search */}
              <div className="p-6 border-b border-white/10">
                <div className="relative">
                  <Search className={`absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-400'}`} />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search users..."
                    className={`w-full pl-12 pr-4 py-3 rounded-xl border-2 transition-colors ${
                      theme === 'dark'
                        ? 'bg-white/[0.06] border-white/[0.2] text-white placeholder:text-[#A7A7AD] focus:border-lime'
                        : 'bg-gray-50 border-gray-200 text-gray-900 placeholder:text-gray-400 focus:border-lime'
                    }`}
                  />
                </div>
              </div>

              {/* Users Table */}
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className={`border-b ${theme === 'dark' ? 'border-white/10' : 'border-gray-200'}`}>
                      <th className={`text-left p-4 text-sm font-medium ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-500'}`}>User</th>
                      <th className={`text-left p-4 text-sm font-medium ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-500'}`}>Joined</th>
                      <th className={`text-left p-4 text-sm font-medium ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-500'}`}>XP</th>
                      <th className={`text-left p-4 text-sm font-medium ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-500'}`}>Status</th>
                      <th className={`text-right p-4 text-sm font-medium ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-500'}`}>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredUsers.map((user) => (
                      <tr key={user.id} className={`border-b ${theme === 'dark' ? 'border-white/5' : 'border-gray-100'}`}>
                        <td className="p-4">
                          <div className="flex items-center gap-3">
                            <div className={`w-10 h-10 rounded-full flex items-center justify-center ${theme === 'dark' ? 'bg-white/10' : 'bg-gray-100'}`}>
                              <span className="text-lime font-bold">{user.name.charAt(0)}</span>
                            </div>
                            <div>
                              <p className={`font-medium ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>{user.name}</p>
                              <p className={`text-sm ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-500'}`}>{user.email}</p>
                            </div>
                          </div>
                        </td>
                        <td className={`p-4 text-sm ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-600'}`}>
                          {user.joined}
                        </td>
                        <td className="p-4">
                          <span className="text-lime font-medium">{user.xp.toLocaleString()}</span>
                        </td>
                        <td className="p-4">
                          <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                            user.status === 'active' 
                              ? 'bg-green-500/20 text-green-400' 
                              : 'bg-red-500/20 text-red-400'
                          }`}>
                            {user.status}
                          </span>
                        </td>
                        <td className="p-4 text-right">
                          <button
                            onClick={() => toggleUserStatus(user.id)}
                            className={`p-2 rounded-lg transition-colors ${
                              user.status === 'active'
                                ? 'hover:bg-red-500/20 text-red-400'
                                : 'hover:bg-green-500/20 text-green-400'
                            }`}
                          >
                            {user.status === 'active' ? <Ban className="w-5 h-5" /> : <CheckCircle className="w-5 h-5" />}
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'activity' && (
            <div className={`neon-card p-6 ${theme === 'light' ? 'bg-white' : ''}`}>
              <h3 className={`font-semibold mb-6 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                Recent Activity Log
              </h3>
              <div className="space-y-4">
                {[
                  { action: 'User signed up', user: 'Alice Johnson', time: '2 minutes ago', type: 'signup' },
                  { action: 'AI Tutor question', user: 'Bob Smith', time: '5 minutes ago', type: 'tutor' },
                  { action: 'Quiz completed', user: 'David Brown', time: '12 minutes ago', type: 'quiz' },
                  { action: 'Notes generated', user: 'Emma Davis', time: '18 minutes ago', type: 'notes' },
                  { action: 'Homework scanned', user: 'Alice Johnson', time: '25 minutes ago', type: 'scan' },
                ].map((activity, i) => (
                  <div
                    key={i}
                    className={`flex items-center gap-4 p-4 rounded-xl ${theme === 'dark' ? 'bg-white/[0.04]' : 'bg-gray-50'}`}
                  >
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                      activity.type === 'signup' ? 'bg-green-500/20' :
                      activity.type === 'tutor' ? 'bg-violet/20' :
                      activity.type === 'quiz' ? 'bg-lime/20' :
                      activity.type === 'notes' ? 'bg-blue-500/20' :
                      'bg-orange-500/20'
                    }`}>
                      {activity.type === 'signup' && <Users className="w-5 h-5 text-green-400" />}
                      {activity.type === 'tutor' && <FileText className="w-5 h-5 text-violet" />}
                      {activity.type === 'quiz' && <HelpCircle className="w-5 h-5 text-lime" />}
                      {activity.type === 'notes' && <FileText className="w-5 h-5 text-blue-400" />}
                      {activity.type === 'scan' && <Camera className="w-5 h-5 text-orange-400" />}
                    </div>
                    <div className="flex-1">
                      <p className={`font-medium ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                        {activity.action}
                      </p>
                      <p className={`text-sm ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-500'}`}>
                        by {activity.user}
                      </p>
                    </div>
                    <span className={`text-sm ${theme === 'dark' ? 'text-[#A7A7AD]' : 'text-gray-500'}`}>
                      {activity.time}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
