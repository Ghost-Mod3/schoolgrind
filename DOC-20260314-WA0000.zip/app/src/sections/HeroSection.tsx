import { useEffect, useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight, Calendar, Clock, Layers } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const HeroSection = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const tileARef = useRef<HTMLDivElement>(null);
  const tileBRef = useRef<HTMLDivElement>(null);
  const tileCRef = useRef<HTMLDivElement>(null);
  const tileDRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const ctaRef = useRef<HTMLButtonElement>(null);

  // Load animation (auto-play on mount)
  useEffect(() => {
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({ defaults: { ease: 'power2.out' } });

      // Tiles entrance
      tl.fromTo(
        tileARef.current,
        { x: '-60vw', opacity: 0 },
        { x: 0, opacity: 1, duration: 1 },
        0
      )
        .fromTo(
          tileBRef.current,
          { y: '-40vh', opacity: 0 },
          { y: 0, opacity: 1, duration: 1 },
          0.08
        )
        .fromTo(
          tileCRef.current,
          { x: '60vw', opacity: 0 },
          { x: 0, opacity: 1, duration: 1 },
          0.16
        )
        .fromTo(
          tileDRef.current,
          { y: '60vh', scale: 0.92, opacity: 0 },
          { y: 0, scale: 1, opacity: 1, duration: 1 },
          0.24
        );

      // Headline words
      if (headlineRef.current) {
        const words = headlineRef.current.querySelectorAll('.word');
        tl.fromTo(
          words,
          { y: 24, opacity: 0 },
          { y: 0, opacity: 1, stagger: 0.04, duration: 0.6 },
          0.4
        );
      }

      // CTA button
      tl.fromTo(
        ctaRef.current,
        { scale: 0.9, opacity: 0 },
        { scale: 1, opacity: 1, duration: 0.5, ease: 'back.out(1.6)' },
        0.7
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  // Scroll-driven exit animation
  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
          onLeaveBack: () => {
            // Reset all elements to visible when scrolling back to top
            gsap.set([tileARef.current, tileBRef.current, tileCRef.current, tileDRef.current], {
              opacity: 1,
              x: 0,
              y: 0,
            });
          },
        },
      });

      // EXIT phase (70% - 100%)
      scrollTl
        .fromTo(
          tileDRef.current,
          { x: 0, opacity: 1 },
          { x: '55vw', opacity: 0, ease: 'power2.in' },
          0.7
        )
        .fromTo(
          tileARef.current,
          { x: 0, opacity: 1 },
          { x: '-40vw', opacity: 0, ease: 'power2.in' },
          0.7
        )
        .fromTo(
          tileBRef.current,
          { y: 0, opacity: 1 },
          { y: '-30vh', opacity: 0, ease: 'power2.in' },
          0.75
        )
        .fromTo(
          tileCRef.current,
          { x: 0, opacity: 1 },
          { x: '40vw', opacity: 0, ease: 'power2.in' },
          0.75
        );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="section-pinned bg-[#0B0B0D] gradient-radial-violet z-10"
    >
      {/* Tile A - Calendar (Left) */}
      <div
        ref={tileARef}
        className="absolute neon-card overflow-hidden"
        style={{
          left: '6vw',
          top: '18vh',
          width: '26vw',
          height: '62vh',
          minWidth: '280px',
        }}
      >
        <img
          src="/images/hero_student_writing.jpg"
          alt="Student studying"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0B0B0D]/80 to-transparent" />
        <div className="absolute bottom-6 left-6 right-6">
          <Calendar className="text-lime w-8 h-8 mb-3" />
          <p className="text-white font-display font-semibold text-lg">
            Weekly Planner
          </p>
          <p className="text-[#A7A7AD] text-sm">Organize your schedule</p>
        </div>
      </div>

      {/* Tile B - Clock (Top Center) */}
      <div
        ref={tileBRef}
        className="absolute neon-card overflow-hidden"
        style={{
          left: '34vw',
          top: '10vh',
          width: '26vw',
          height: '34vh',
          minWidth: '260px',
        }}
      >
        <img
          src="/images/focus_student_laptop.jpg"
          alt="Focus session"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0B0B0D]/80 to-transparent" />
        <div className="absolute bottom-4 left-4 right-4">
          <Clock className="text-lime w-6 h-6 mb-2" />
          <p className="text-white font-display font-semibold">Focus Timer</p>
        </div>
      </div>

      {/* Tile C - Stack (Top Right) */}
      <div
        ref={tileCRef}
        className="absolute neon-card overflow-hidden"
        style={{
          left: '66vw',
          top: '10vh',
          width: '28vw',
          height: '34vh',
          minWidth: '280px',
        }}
      >
        <img
          src="/images/study_materials_stack.jpg"
          alt="Study materials"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0B0B0D]/80 to-transparent" />
        <div className="absolute bottom-4 left-4 right-4">
          <Layers className="text-lime w-6 h-6 mb-2" />
          <p className="text-white font-display font-semibold">Study Notes</p>
        </div>
      </div>

      {/* Tile D - CTA Card (Bottom Right) */}
      <div
        ref={tileDRef}
        className="absolute neon-card neon-card-lime p-8 flex flex-col justify-between"
        style={{
          left: '34vw',
          top: '50vh',
          width: '60vw',
          height: '40vh',
          minWidth: '320px',
          minHeight: '280px',
        }}
      >
        <div>
          <h1
            ref={headlineRef}
            className="font-display font-bold text-white uppercase leading-[0.95] mb-4"
            style={{ fontSize: 'clamp(28px, 4vw, 56px)' }}
          >
            <span className="word inline-block">STUDY</span>{' '}
            <span className="word inline-block">SMARTER.</span>
            <br />
            <span className="word inline-block text-lime">STRESS</span>{' '}
            <span className="word inline-block text-lime">LESS.</span>
          </h1>
          <p className="text-[#A7A7AD] text-base sm:text-lg max-w-md">
            A weekly planner built for students. Drag, drop, and actually get
            things done.
          </p>
        </div>

        <div className="flex items-end justify-between">
          <div>
            <button ref={ctaRef} className="btn-lime flex items-center gap-2">
              Get Started
              <ArrowRight className="w-4 h-4" />
            </button>
            <p className="text-[#A7A7AD] text-xs mt-3">
              Free for students. No credit card.
            </p>
          </div>
          <ArrowRight className="text-lime w-8 h-8 hidden sm:block" />
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
