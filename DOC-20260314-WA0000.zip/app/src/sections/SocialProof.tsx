import { useLayoutEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { GraduationCap } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const SocialProof = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const sublineRef = useRef<HTMLParagraphElement>(null);
  const barRef = useRef<HTMLDivElement>(null);
  const statsRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // ENTRANCE (0% - 30%)
      scrollTl
        .fromTo(
          panelRef.current,
          { y: '100vh' },
          { y: 0, ease: 'none' },
          0
        )
        .fromTo(
          headlineRef.current?.querySelectorAll('.word') || [],
          { y: 40, opacity: 0 },
          { y: 0, opacity: 1, stagger: 0.03, ease: 'none' },
          0.05
        )
        .fromTo(
          sublineRef.current,
          { y: 20, opacity: 0 },
          { y: 0, opacity: 1, ease: 'none' },
          0.15
        )
        .fromTo(
          barRef.current,
          { scaleX: 0 },
          { scaleX: 1, ease: 'none' },
          0.12
        )
        .fromTo(
          statsRef.current?.children || [],
          { y: 30, opacity: 0 },
          { y: 0, opacity: 1, stagger: 0.05, ease: 'none' },
          0.18
        );

      // EXIT (70% - 100%)
      scrollTl
        .to(panelRef.current, { y: '-100vh', ease: 'power2.in' }, 0.7)
        .to(
          headlineRef.current?.querySelectorAll('.word') || [],
          { y: -30, opacity: 0, stagger: 0.02, ease: 'power2.in' },
          0.7
        );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const stats = [
    { value: '20K+', label: 'Students' },
    { value: '500+', label: 'Schools' },
    { value: '1M+', label: 'Tasks Completed' },
  ];

  return (
    <section ref={sectionRef} className="section-pinned z-[80]">
      <div
        ref={panelRef}
        className="absolute inset-0 bg-violet flex items-center justify-center"
      >
        <div className="text-center px-6 max-w-4xl">
          <GraduationCap className="text-lime w-16 h-16 mx-auto mb-6" />
          <h2
            ref={headlineRef}
            className="font-display font-bold text-white uppercase leading-tight mb-6"
            style={{ fontSize: 'clamp(32px, 5vw, 72px)' }}
          >
            <span className="word inline-block">JOIN</span>{' '}
            <span className="word inline-block">20,000+</span>{' '}
            <span className="word inline-block">STUDENTS.</span>
          </h2>
          <p
            ref={sublineRef}
            className="text-white/80 text-lg sm:text-xl max-w-2xl mx-auto mb-10"
          >
            From high school to university, students use SchoolGrind to stay
            organized, focused, and less stressed.
          </p>
          <div
            ref={barRef}
            className="lime-accent-bar w-32 mx-auto mb-10"
            style={{ transformOrigin: 'center' }}
          />
          <div ref={statsRef} className="flex justify-center gap-12 sm:gap-16">
            {stats.map((stat, i) => (
              <div key={i} className="text-center">
                <p className="text-lime font-display font-bold text-3xl sm:text-4xl">
                  {stat.value}
                </p>
                <p className="text-white/70 text-sm mt-1">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default SocialProof;
