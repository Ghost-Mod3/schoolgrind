import { useLayoutEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight, CheckSquare } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const FeatureTasks = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const tileARef = useRef<HTMLDivElement>(null);
  const tileBRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // ENTRANCE (0% - 30%)
      scrollTl
        .fromTo(
          tileARef.current,
          { x: '-70vw', opacity: 0 },
          { x: 0, opacity: 1, ease: 'none' },
          0
        )
        .fromTo(
          tileBRef.current,
          { x: '70vw', opacity: 0 },
          { x: 0, opacity: 1, ease: 'none' },
          0
        )
        .fromTo(
          headlineRef.current?.querySelectorAll('.word') || [],
          { y: 28, opacity: 0 },
          { y: 0, opacity: 1, stagger: 0.04, ease: 'none' },
          0.08
        );

      // EXIT (70% - 100%)
      scrollTl
        .to(tileARef.current, { x: '-35vw', opacity: 0, ease: 'power2.in' }, 0.7)
        .to(tileBRef.current, { x: '35vw', opacity: 0, ease: 'power2.in' }, 0.7);
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} className="section-pinned bg-[#0B0B0D] z-[60]">
      {/* Tile A - CTA Card (Left) */}
      <div
        ref={tileARef}
        className="absolute neon-card neon-card-lime p-8 flex flex-col justify-center"
        style={{
          left: '6vw',
          top: '16vh',
          width: '40vw',
          height: '68vh',
          minWidth: '300px',
        }}
      >
        <div>
          <CheckSquare className="text-lime w-8 h-8 mb-4" />
          <h2
            ref={headlineRef}
            className="font-display font-bold text-white uppercase leading-tight mb-6"
            style={{ fontSize: 'clamp(32px, 4vw, 64px)' }}
          >
            <span className="word inline-block">STAY</span>{' '}
            <span className="word inline-block text-lime">ON</span>{' '}
            <span className="word inline-block text-lime">TRACK.</span>
          </h2>
          <p className="text-[#A7A7AD] text-base sm:text-lg mb-8 max-w-md">
            Tasks, reminders, and small wins—built into every study session.
            Check things off and keep momentum.
          </p>
          <button className="btn-lime flex items-center gap-2">
            Explore tasks
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Tile B - Tasks UI (Right) */}
      <div
        ref={tileBRef}
        className="absolute neon-card overflow-hidden"
        style={{
          left: '50vw',
          top: '16vh',
          width: '44vw',
          height: '68vh',
          minWidth: '320px',
        }}
      >
        <img
          src="/images/tasks_ui.jpg"
          alt="Tasks UI"
          className="w-full h-full object-cover"
        />
      </div>
    </section>
  );
};

export default FeatureTasks;
