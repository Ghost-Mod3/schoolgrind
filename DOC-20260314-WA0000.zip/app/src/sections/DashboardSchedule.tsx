import { useLayoutEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Calendar, ChevronRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const DashboardSchedule = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const leftColRef = useRef<HTMLDivElement>(null);
  const centerColRef = useRef<HTMLDivElement>(null);
  const rightColRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      const cards = [
        ...(leftColRef.current?.children || []),
        ...(centerColRef.current?.children || []),
        ...(rightColRef.current?.children || []),
      ];

      gsap.fromTo(
        cards,
        { y: 40, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          stagger: 0.08,
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
            end: 'top 55%',
            scrub: 0.5,
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="dashboard"
      className="relative bg-[#0B0B0D] py-16 sm:py-24 z-[100]"
    >
      <div className="px-4 sm:px-6 lg:px-8 xl:px-12">
        <div className="flex items-center gap-3 mb-8">
          <Calendar className="text-lime w-6 h-6" />
          <h2 className="font-display font-bold text-white text-2xl sm:text-3xl">
            Your week
          </h2>
        </div>
        <p className="text-[#A7A7AD] mb-10 max-w-md">
          Drag to reschedule. Click any block to edit details.
        </p>

        {/* Dashboard Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column */}
          <div ref={leftColRef} className="lg:col-span-3 space-y-6">
            {/* Profile Card */}
            <div className="neon-card p-6">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-12 h-12 rounded-full bg-lime/20 flex items-center justify-center">
                  <span className="text-lime font-bold text-lg">JD</span>
                </div>
                <div>
                  <p className="text-white font-semibold">John Doe</p>
                  <p className="text-[#A7A7AD] text-sm">Computer Science</p>
                </div>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-[#A7A7AD]">Study Streak</span>
                <span className="text-lime font-semibold">12 days</span>
              </div>
            </div>

            {/* Quick Add Card */}
            <div className="neon-card p-6">
              <p className="text-white font-semibold mb-4">Quick Add</p>
              <div className="space-y-3">
                <button className="w-full text-left px-4 py-3 rounded-xl bg-white/[0.06] hover:bg-white/[0.1] transition-colors text-sm text-[#A7A7AD]">
                  + Add class
                </button>
                <button className="w-full text-left px-4 py-3 rounded-xl bg-white/[0.06] hover:bg-white/[0.1] transition-colors text-sm text-[#A7A7AD]">
                  + Add task
                </button>
                <button className="w-full text-left px-4 py-3 rounded-xl bg-white/[0.06] hover:bg-white/[0.1] transition-colors text-sm text-[#A7A7AD]">
                  + Add reminder
                </button>
              </div>
            </div>
          </div>

          {/* Center Column - Schedule */}
          <div ref={centerColRef} className="lg:col-span-6">
            <div className="neon-card p-6 h-full">
              <div className="flex items-center justify-between mb-6">
                <p className="text-white font-semibold">Weekly Schedule</p>
                <button className="text-lime text-sm flex items-center gap-1 hover:underline">
                  Open full calendar
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>

              {/* Days */}
              <div className="grid grid-cols-7 gap-2 mb-4">
                {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map(
                  (day, i) => (
                    <div
                      key={day}
                      className={`text-center py-2 rounded-lg text-sm ${
                        i === 0
                          ? 'bg-lime text-[#0B0B0D] font-semibold'
                          : 'text-[#A7A7AD]'
                      }`}
                    >
                      {day}
                    </div>
                  )
                )}
              </div>

              {/* Time Slots */}
              <div className="space-y-2">
                {[
                  { time: '9:00 AM', subject: 'Mathematics', color: 'bg-violet' },
                  { time: '11:00 AM', subject: 'Computer Science', color: 'bg-lime' },
                  { time: '2:00 PM', subject: 'Physics', color: 'bg-violet' },
                  { time: '4:00 PM', subject: 'Study Group', color: 'bg-lime' },
                ].map((slot, i) => (
                  <div
                    key={i}
                    className="flex items-center gap-4 p-3 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] transition-colors cursor-pointer"
                  >
                    <span className="text-[#A7A7AD] text-sm w-20">
                      {slot.time}
                    </span>
                    <div
                      className={`flex-1 h-10 rounded-lg ${slot.color} flex items-center px-4`}
                    >
                      <span
                        className={`font-medium text-sm ${
                          slot.color === 'bg-lime'
                            ? 'text-[#0B0B0D]'
                            : 'text-white'
                        }`}
                      >
                        {slot.subject}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column */}
          <div ref={rightColRef} className="lg:col-span-3 space-y-6">
            {/* Stats Card */}
            <div className="neon-card p-6">
              <p className="text-white font-semibold mb-4">This Week</p>
              <div className="space-y-4">
                <div>
                  <p className="text-[#A7A7AD] text-sm">Study Hours</p>
                  <p className="text-lime font-bold text-2xl">24.5</p>
                </div>
                <div>
                  <p className="text-[#A7A7AD] text-sm">Tasks Done</p>
                  <p className="text-lime font-bold text-2xl">18/22</p>
                </div>
              </div>
            </div>

            {/* Deadlines Card */}
            <div className="neon-card p-6">
              <p className="text-white font-semibold mb-4">Upcoming</p>
              <div className="space-y-3">
                {[
                  { task: 'Math Assignment', date: 'Tomorrow' },
                  { task: 'CS Project', date: 'In 3 days' },
                  { task: 'Physics Quiz', date: 'Next week' },
                ].map((item, i) => (
                  <div
                    key={i}
                    className="flex items-center justify-between py-2 border-b border-white/[0.1] last:border-0"
                  >
                    <span className="text-white text-sm">{item.task}</span>
                    <span className="text-[#A7A7AD] text-xs">{item.date}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default DashboardSchedule;
