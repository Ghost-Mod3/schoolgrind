import { useLayoutEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const StatementSection = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const sublineRef = useRef<HTMLParagraphElement>(null);
  const barRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // ENTRANCE (0% - 30%)
      scrollTl
        .fromTo(
          panelRef.current,
          { y: '100vh' },
          { y: 0, ease: 'none' },
          0
        )
        .fromTo(
          headlineRef.current?.querySelectorAll('.word') || [],
          { y: 40, opacity: 0 },
          { y: 0, opacity: 1, stagger: 0.03, ease: 'none' },
          0.05
        )
        .fromTo(
          sublineRef.current,
          { y: 20, opacity: 0 },
          { y: 0, opacity: 1, ease: 'none' },
          0.15
        )
        .fromTo(
          barRef.current,
          { scaleX: 0 },
          { scaleX: 1, ease: 'none' },
          0.12
        );

      // EXIT (70% - 100%)
      scrollTl
        .to(
          panelRef.current,
          { y: '-100vh', ease: 'power2.in' },
          0.7
        )
        .to(
          headlineRef.current?.querySelectorAll('.word') || [],
          { y: -30, opacity: 0, stagger: 0.02, ease: 'power2.in' },
          0.7
        )
        .to(
          barRef.current,
          { scaleX: 0, ease: 'power2.in' },
          0.7
        );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const headlineText = 'BUILT FOR THE WAY YOU ACTUALLY STUDY.';

  return (
    <section ref={sectionRef} className="section-pinned z-20">
      <div
        ref={panelRef}
        className="absolute inset-0 bg-violet flex items-center justify-center"
      >
        <div className="text-center px-6 max-w-4xl">
          <h2
            ref={headlineRef}
            className="font-display font-bold text-white uppercase leading-tight mb-6"
            style={{ fontSize: 'clamp(32px, 5vw, 72px)' }}
          >
            {headlineText.split(' ').map((word, i) => (
              <span key={i} className="word inline-block mr-[0.3em]">
                {word}
              </span>
            ))}
          </h2>
          <p
            ref={sublineRef}
            className="text-white/80 text-lg sm:text-xl max-w-2xl mx-auto"
          >
            Not another generic calendar. SchoolGrind is designed around real
            student routines—classes, deadlines, focus sessions, and late-night
            cramming.
          </p>
          <div
            ref={barRef}
            className="lime-accent-bar w-32 mx-auto mt-8"
            style={{ transformOrigin: 'center' }}
          />
        </div>
      </div>
    </section>
  );
};

export default StatementSection;
