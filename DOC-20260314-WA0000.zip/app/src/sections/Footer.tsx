import { useLayoutEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Twitter, Instagram, Github, Linkedin } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const Footer = () => {
  const footerRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        contentRef.current,
        { y: 20, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          scrollTrigger: {
            trigger: footerRef.current,
            start: 'top 90%',
            end: 'top 70%',
            scrub: 0.5,
          },
        }
      );
    }, footerRef);

    return () => ctx.revert();
  }, []);

  const links = {
    Product: ['Features', 'Dashboard', 'Pricing', 'Changelog'],
    Support: ['Help Center', 'Contact', 'Feedback', 'Community'],
    Legal: ['Privacy', 'Terms', 'Cookies', 'Security'],
  };

  const socials = [
    { icon: Twitter, href: '#' },
    { icon: Instagram, href: '#' },
    { icon: Github, href: '#' },
    { icon: Linkedin, href: '#' },
  ];

  return (
    <footer
      ref={footerRef}
      id="support"
      className="relative bg-[#0B0B0D] pt-16 pb-8"
    >
      <div ref={contentRef} className="px-4 sm:px-6 lg:px-8 xl:px-12">
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 mb-12">
          {/* Brand Column */}
          <div className="lg:col-span-4">
            <a href="#" className="inline-block mb-1">
              <span className="text-lime font-display font-bold text-2xl">
                SchoolGrind
              </span>
            </a>
            <p className="text-[#A7A7AD] text-sm tracking-wider mb-4">
              Ghostmode Chatty - Edition
            </p>
            <p className="text-[#A7A7AD] mb-6 max-w-sm">
              Study smarter. Stress less. The weekly planner built for students
              who want to actually get things done.
            </p>
            <button className="btn-lime text-sm">Get Started</button>
          </div>

          {/* Links Columns */}
          <div className="lg:col-span-8">
            <div className="grid grid-cols-3 gap-8">
              {Object.entries(links).map(([category, items]) => (
                <div key={category}>
                  <p className="text-white font-semibold mb-4">{category}</p>
                  <ul className="space-y-3">
                    {items.map((item) => (
                      <li key={item}>
                        <a
                          href="#"
                          className="text-[#A7A7AD] text-sm hover:text-lime transition-colors"
                        >
                          {item}
                        </a>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Divider */}
        <div className="h-px bg-white/[0.1] mb-8" />

        {/* Bottom Row */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-[#A7A7AD] text-sm">
            © 2026 SchoolGrind. All rights reserved.
          </p>

          {/* Social Icons */}
          <div className="flex items-center gap-4">
            {socials.map((social, i) => (
              <a
                key={i}
                href={social.href}
                className="w-10 h-10 rounded-full bg-white/[0.06] flex items-center justify-center text-[#A7A7AD] hover:bg-lime hover:text-[#0B0B0D] transition-colors"
              >
                <social.icon className="w-5 h-5" />
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
