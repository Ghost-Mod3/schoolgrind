import { useLayoutEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight, Rocket } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const FinalCTA = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const ctaRef = useRef<HTMLButtonElement>(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // ENTRANCE (0% - 30%)
      scrollTl
        .fromTo(
          cardRef.current,
          { y: '100vh', scale: 0.92, opacity: 0 },
          { y: 0, scale: 1, opacity: 1, ease: 'none' },
          0
        )
        .fromTo(
          headlineRef.current?.querySelectorAll('.word') || [],
          { y: 28, opacity: 0 },
          { y: 0, opacity: 1, stagger: 0.04, ease: 'none' },
          0.08
        )
        .fromTo(
          ctaRef.current,
          { scale: 0.9, opacity: 0 },
          { scale: 1, opacity: 1, ease: 'back.out(1.6)' },
          0.18
        );

      // EXIT (70% - 100%)
      scrollTl
        .to(cardRef.current, { y: '-40vh', opacity: 0, ease: 'power2.in' }, 0.7)
        .to(ctaRef.current, { scale: 0.96, opacity: 0, ease: 'power2.in' }, 0.7);
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} className="section-pinned bg-[#0B0B0D] z-[90]">
      <div
        ref={cardRef}
        className="absolute neon-card neon-card-lime p-10 sm:p-16 flex flex-col items-center justify-center text-center"
        style={{
          left: '50%',
          top: '50%',
          transform: 'translate(-50%, -50%)',
          width: 'min(86vw, 1200px)',
          height: '72vh',
          minHeight: '400px',
        }}
      >
        <Rocket className="text-lime w-12 h-12 mb-6" />
        <h2
          ref={headlineRef}
          className="font-display font-bold text-white uppercase leading-tight mb-6"
          style={{ fontSize: 'clamp(36px, 6vw, 84px)' }}
        >
          <span className="word inline-block">READY</span>{' '}
          <span className="word inline-block">TO</span>{' '}
          <span className="word inline-block text-lime">GRIND?</span>
        </h2>
        <p className="text-[#A7A7AD] text-lg sm:text-xl mb-10 max-w-lg">
          Start your week with a plan. Finish it with progress.
        </p>
        <button
          ref={ctaRef}
          className="btn-lime flex items-center gap-2 text-lg px-8 py-4"
        >
          Get Started
          <ArrowRight className="w-5 h-5" />
        </button>
        <p className="text-[#A7A7AD] text-sm mt-4">
          Free. No spam. Unsubscribe anytime.
        </p>
        <ArrowRight className="text-lime w-8 h-8 absolute right-8 bottom-8 hidden sm:block" />
      </div>
    </section>
  );
};

export default FinalCTA;
