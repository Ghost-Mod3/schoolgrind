import { useLayoutEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Timer, Play, Pause, RotateCcw, CheckCircle2 } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const DashboardFocus = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const leftCardRef = useRef<HTMLDivElement>(null);
  const rightCardRef = useRef<HTMLDivElement>(null);
  const [isRunning, setIsRunning] = useState(false);
  const [timeLeft, setTimeLeft] = useState(25 * 60);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        leftCardRef.current,
        { x: '-6vw', opacity: 0 },
        {
          x: 0,
          opacity: 1,
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
            end: 'top 55%',
            scrub: 0.5,
          },
        }
      );

      gsap.fromTo(
        rightCardRef.current,
        { x: '6vw', opacity: 0 },
        {
          x: 0,
          opacity: 1,
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
            end: 'top 55%',
            scrub: 0.5,
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs
      .toString()
      .padStart(2, '0')}`;
  };

  const toggleTimer = () => {
    setIsRunning(!isRunning);
  };

  const resetTimer = () => {
    setIsRunning(false);
    setTimeLeft(25 * 60);
  };

  const tasks = [
    { id: 1, text: 'Complete math homework', done: true },
    { id: 2, text: 'Review CS lecture notes', done: false },
    { id: 3, text: 'Read physics chapter 5', done: false },
    { id: 4, text: 'Practice coding problems', done: false },
  ];

  return (
    <section ref={sectionRef} className="relative bg-[#0B0B0D] py-16 sm:py-24">
      <div className="px-4 sm:px-6 lg:px-8 xl:px-12">
        <div className="flex items-center gap-3 mb-8">
          <Timer className="text-lime w-6 h-6" />
          <h2 className="font-display font-bold text-white text-2xl sm:text-3xl">
            Focus mode
          </h2>
        </div>
        <p className="text-[#A7A7AD] mb-10 max-w-md">
          Pick one task. Start the timer. Stay until the bell.
        </p>

        {/* Dashboard Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Focus Timer Card */}
          <div ref={leftCardRef} className="neon-card p-8">
            <div className="flex flex-col items-center">
              {/* Timer Circle */}
              <div className="relative w-64 h-64 mb-8">
                <svg className="w-full h-full transform -rotate-90">
                  <circle
                    cx="128"
                    cy="128"
                    r="120"
                    stroke="rgba(255,255,255,0.1)"
                    strokeWidth="12"
                    fill="none"
                  />
                  <circle
                    cx="128"
                    cy="128"
                    r="120"
                    stroke="#B8FF2C"
                    strokeWidth="12"
                    fill="none"
                    strokeLinecap="round"
                    strokeDasharray={`${(timeLeft / (25 * 60)) * 754} 754`}
                    className="transition-all duration-1000"
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-white font-display font-bold text-5xl">
                    {formatTime(timeLeft)}
                  </span>
                  <span className="text-[#A7A7AD] text-sm mt-2">FOCUS</span>
                </div>
              </div>

              {/* Controls */}
              <div className="flex items-center gap-4">
                <button
                  onClick={toggleTimer}
                  className="w-14 h-14 rounded-full bg-lime flex items-center justify-center hover:scale-105 transition-transform"
                >
                  {isRunning ? (
                    <Pause className="w-6 h-6 text-[#0B0B0D]" />
                  ) : (
                    <Play className="w-6 h-6 text-[#0B0B0D] ml-1" />
                  )}
                </button>
                <button
                  onClick={resetTimer}
                  className="w-14 h-14 rounded-full border-2 border-white/[0.2] flex items-center justify-center hover:bg-white/[0.1] transition-colors"
                >
                  <RotateCcw className="w-5 h-5 text-white" />
                </button>
              </div>
            </div>
          </div>

          {/* Task Checklist Card */}
          <div ref={rightCardRef} className="neon-card p-8">
            <p className="text-white font-semibold mb-6">Today's Tasks</p>
            <div className="space-y-3">
              {tasks.map((task) => (
                <div
                  key={task.id}
                  className="flex items-center gap-4 p-4 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] transition-colors cursor-pointer"
                >
                  <CheckCircle2
                    className={`w-6 h-6 flex-shrink-0 ${
                      task.done ? 'text-lime' : 'text-white/[0.3]'
                    }`}
                  />
                  <span
                    className={`text-sm ${
                      task.done
                        ? 'text-[#A7A7AD] line-through'
                        : 'text-white'
                    }`}
                  >
                    {task.text}
                  </span>
                </div>
              ))}
            </div>
            <button className="w-full mt-6 py-3 rounded-xl border-2 border-dashed border-white/[0.2] text-[#A7A7AD] text-sm hover:border-lime hover:text-lime transition-colors">
              + Add a task
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default DashboardFocus;
