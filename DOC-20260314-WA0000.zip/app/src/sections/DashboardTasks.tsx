import { useLayoutEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { CheckSquare, Bell, Zap, Plus } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const DashboardTasks = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const leftCardRef = useRef<HTMLDivElement>(null);
  const rightCardsRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        leftCardRef.current,
        { y: 30, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
            end: 'top 55%',
            scrub: 0.5,
          },
        }
      );

      gsap.fromTo(
        rightCardsRef.current?.children || [],
        { y: 30, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          stagger: 0.1,
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
            end: 'top 55%',
            scrub: 0.5,
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const tasks = [
    { id: 1, text: 'Review calculus notes', priority: 'high', done: false },
    { id: 2, text: 'Submit CS assignment', priority: 'high', done: true },
    { id: 3, text: 'Read physics chapter', priority: 'medium', done: false },
    { id: 4, text: 'Practice coding problems', priority: 'medium', done: false },
    { id: 5, text: 'Organize study desk', priority: 'low', done: true },
  ];

  const reminders = [
    { text: 'Math quiz tomorrow', time: '9:00 AM' },
    { text: 'Group study session', time: '3:00 PM' },
  ];

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'bg-red-500/20 text-red-400';
      case 'medium':
        return 'bg-yellow-500/20 text-yellow-400';
      case 'low':
        return 'bg-green-500/20 text-green-400';
      default:
        return 'bg-white/10 text-[#A7A7AD]';
    }
  };

  return (
    <section ref={sectionRef} className="relative bg-[#0B0B0D] py-16 sm:py-24">
      <div className="px-4 sm:px-6 lg:px-8 xl:px-12">
        <div className="flex items-center gap-3 mb-8">
          <CheckSquare className="text-lime w-6 h-6" />
          <h2 className="font-display font-bold text-white text-2xl sm:text-3xl">
            Tasks & reminders
          </h2>
        </div>
        <p className="text-[#A7A7AD] mb-10 max-w-md">
          Check off what's done. We'll remind you what's next.
        </p>

        {/* Dashboard Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Tasks Card */}
          <div ref={leftCardRef} className="lg:col-span-7">
            <div className="neon-card p-6">
              <div className="flex items-center justify-between mb-6">
                <p className="text-white font-semibold">All Tasks</p>
                <button className="btn-lime text-sm flex items-center gap-2 py-2 px-4">
                  <Plus className="w-4 h-4" />
                  Add a task
                </button>
              </div>

              <div className="space-y-3">
                {tasks.map((task) => (
                  <div
                    key={task.id}
                    className="flex items-center gap-4 p-4 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] transition-colors cursor-pointer group"
                  >
                    <div
                      className={`w-5 h-5 rounded border-2 flex items-center justify-center transition-colors ${
                        task.done
                          ? 'bg-lime border-lime'
                          : 'border-white/[0.3] group-hover:border-lime'
                      }`}
                    >
                      {task.done && (
                        <CheckSquare className="w-3 h-3 text-[#0B0B0D]" />
                      )}
                    </div>
                    <span
                      className={`flex-1 text-sm ${
                        task.done
                          ? 'text-[#A7A7AD] line-through'
                          : 'text-white'
                      }`}
                    >
                      {task.text}
                    </span>
                    <span
                      className={`text-xs px-3 py-1 rounded-full capitalize ${getPriorityColor(
                        task.priority
                      )}`}
                    >
                      {task.priority}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column */}
          <div ref={rightCardsRef} className="lg:col-span-5 space-y-6">
            {/* Reminders Card */}
            <div className="neon-card p-6">
              <div className="flex items-center gap-3 mb-4">
                <Bell className="text-lime w-5 h-5" />
                <p className="text-white font-semibold">Reminders</p>
              </div>
              <div className="space-y-3">
                {reminders.map((reminder, i) => (
                  <div
                    key={i}
                    className="flex items-center justify-between p-3 rounded-xl bg-white/[0.04]"
                  >
                    <span className="text-white text-sm">{reminder.text}</span>
                    <span className="text-lime text-xs">{reminder.time}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Habits Mini Card */}
            <div className="neon-card p-6">
              <div className="flex items-center gap-3 mb-4">
                <Zap className="text-lime w-5 h-5" />
                <p className="text-white font-semibold">Daily Habits</p>
              </div>
              <div className="grid grid-cols-7 gap-2">
                {['M', 'T', 'W', 'T', 'F', 'S', 'S'].map((day, i) => (
                  <div
                    key={i}
                    className={`aspect-square rounded-lg flex items-center justify-center text-sm font-medium ${
                      i < 5
                        ? 'bg-lime text-[#0B0B0D]'
                        : 'bg-white/[0.06] text-[#A7A7AD]'
                    }`}
                  >
                    {i < 5 ? '✓' : day}
                  </div>
                ))}
              </div>
              <p className="text-[#A7A7AD] text-sm mt-4">
                5-day streak! Keep it up!
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default DashboardTasks;
