import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Sun, Moon } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';

const Navigation = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { theme, toggleTheme } = useTheme();
  const location = useLocation();
  const isLandingPage = location.pathname === '/';

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 100);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Features', href: '#features' },
    { label: 'Dashboard', href: '/dashboard' },
    { label: 'Pricing', href: '#pricing' },
    { label: 'Support', href: '#support' },
  ];

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
          isScrolled || !isLandingPage
            ? theme === 'dark'
              ? 'bg-[#0B0B0D]/90 backdrop-blur-md py-3'
              : 'bg-white/90 backdrop-blur-md py-3 shadow-sm'
            : 'bg-transparent py-4'
        }`}
      >
        <div className="w-full px-4 sm:px-6 lg:px-8 xl:px-12 flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2">
            <span className="text-lime font-display font-bold text-xl sm:text-2xl tracking-tight">
              SchoolGrind
            </span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              link.href.startsWith('#') ? (
                <a
                  key={link.label}
                  href={link.href}
                  className={`transition-colors text-sm font-medium ${
                    theme === 'dark' ? 'text-[#A7A7AD] hover:text-white' : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  {link.label}
                </a>
              ) : (
                <Link
                  key={link.label}
                  to={link.href}
                  className={`transition-colors text-sm font-medium ${
                    theme === 'dark' ? 'text-[#A7A7AD] hover:text-white' : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  {link.label}
                </Link>
              )
            ))}
          </div>

          {/* Right Side Actions */}
          <div className="hidden md:flex items-center gap-4">
            {/* Theme Toggle */}
            <button
              onClick={toggleTheme}
              className={`p-2 rounded-xl transition-colors ${
                theme === 'dark'
                  ? 'bg-white/10 text-white hover:bg-lime hover:text-[#0B0B0D]'
                  : 'bg-gray-100 text-gray-700 hover:bg-lime hover:text-[#0B0B0D]'
              }`}
            >
              {theme === 'dark' ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>

            {/* CTA Button */}
            <Link to="/signup">
              <button className="btn-lime text-sm">Get Started</button>
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button
            className={`md:hidden p-2 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </nav>

      {/* Mobile Menu Overlay */}
      {isMobileMenuOpen && (
        <div className={`fixed inset-0 z-50 ${theme === 'dark' ? 'bg-[#0B0B0D]/98' : 'bg-white/98'} backdrop-blur-lg md:hidden`}>
          <div className="flex flex-col items-center justify-center h-full gap-8">
            {navLinks.map((link) => (
              link.href.startsWith('#') ? (
                <a
                  key={link.label}
                  href={link.href}
                  className={`text-2xl font-display font-semibold ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  {link.label}
                </a>
              ) : (
                <Link
                  key={link.label}
                  to={link.href}
                  className={`text-2xl font-display font-semibold ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  {link.label}
                </Link>
              )
            ))}
            
            {/* Theme Toggle Mobile */}
            <button
              onClick={() => {
                toggleTheme();
                setIsMobileMenuOpen(false);
              }}
              className={`flex items-center gap-3 text-2xl font-display font-semibold ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}
            >
              {theme === 'dark' ? <Sun className="w-6 h-6" /> : <Moon className="w-6 h-6" />}
              {theme === 'dark' ? 'Light Mode' : 'Dark Mode'}
            </button>

            <Link to="/signup" onClick={() => setIsMobileMenuOpen(false)}>
              <button className="btn-lime mt-4">Get the app</button>
            </Link>
          </div>
          <button
            className={`absolute top-4 right-4 p-2 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}
            onClick={() => setIsMobileMenuOpen(false)}
          >
            <X size={28} />
          </button>
        </div>
      )}
    </>
  );
};

export default Navigation;
